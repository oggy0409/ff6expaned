# TECH v0.5 — exact patch tables (generated from build manifests)

Long rows (>512 bytes) show length + SHA-1 of original/new; byte-exact data is in the `.manifest.json` and `.diff.csv` next to each ROM.

## production — `FF6X_Rev1_TECH_v0.5.0_PRODUCTION.sfc`

SHA-1 `34ad5625ed08f791ca98ccde6a1dbf4ba4744cec` · CRC32 `844CC192` · SNES checksum `E399` · status: PRODUCTION BRANCH v0.5 - accepted engine + map foundation + MONSTER EXPANSION FOUNDATION; no content

| ID | PC | SNES | Len | Original | New | Consumer / reason |
|---|---|---|---|---|---|---|
| P000_EXPAND_4MIB | 300000–3FFFFF | F0:0000–FF:FFFF | 1048576 | `` | `FF fill` | All F0-FF expansion allocations. — Expand 3 MiB -> 4 MiB HiROM. Header ROM-size byte C0:FFD7 is already 0x0C (4 MiB class) in Rev 1; unchanged. |
| P001_BUILD_METADATA | 300000–30003F | F0:0000–F0:003F | 64 | `FF fill (expansion)` | `46 46 36 58 2D 45 45 00 01 00 05 00 00 02 00 00 70 72 6F …` | tools/verify (offline). No runtime consumer. — Machine-readable build identity for QA tooling. |
| P101_EXP_DLG_TABLE | 334000–33402A | F3:4000–F3:402A | 43 | `FF fill (expansion)` | `24 37 2F 20 2D 32 28 2E 2D 7F 23 28 20 2B 2E 26 34 24 7F …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1000: 'EXPANSION DIALOGUE ERROR:{n}ID OUT OF RANGE.' |
| P101_EXP_DLG_TABLE | 330000–330003 | F3:0000–F3:0003 | 4 | `FF fill (expansion)` | `00 40 F3 00` | P100 hook (LDA.l table,X) — 1 x 4-byte pointers for dialogue IDs $1000-$1000 |
| P100_DLG_HOOK | 301000–301032 | F0:1000–F0:1032 | 51 | `FF fill (expansion)` | `C2 20 A5 D0 C9 00 10 B0 0A E2 20 A9 CD 85 CB 5C C3 7F C0 …` | JML from C0:7FBF (GetDlgPtr) — Dialogue-pointer hook: vanilla IDs unchanged, IDs $1000+ from expansion table |
| P100_DLG_HOOK | 007FBF–007FC2 | C0:7FBF–C0:7FC2 | 4 | `A9 CD 85 CB` | `5C 00 10 F0` | GetDlgPtr C0:7FBF; callers C0:A49A ($48), C0:A4E1 ($4B), C0:D493 (debug) — Replace LDA #$CD / STA $CB with JML $F01000 (displaced code re-executed in hook) |
| M101_MAPX_EVENT_TRIGGERS | 360000–361ABD | F6:0000–F6:1ABD | 6846 | `FF fill (expansion)` | `<6846 bytes, sha1 0459d4b3017e900ad4df3df1b73afacbd2b68f29>` | 12 retargeted consumers — EVENT_TRIGGERS: 1164 vanilla records (maps $000-$19F) + 0 content records; 513 pointers |
| M102_MAPX_NPC_PROPS | 364000–36911A | F6:4000–F6:911A | 20763 | `FF fill (expansion)` | `<20763 bytes, sha1 9702f8bb1e73beb814adcaa8484e05a1e95d66ff>` | 21 retargeted consumers — NPC_PROPS: 2193 vanilla records (maps $000-$19F) + 0 content records; 513 pointers |
| M103_MAPX_SHORT_ENTRANCES | 36C000–36DE77 | F6:C000–F6:DE77 | 7800 | `FF fill (expansion)` | `<7800 bytes, sha1 d3f67399eb1dcabdfc1a13264f8d2f948cb72027>` | 19 retargeted consumers — SHORT_ENTRANCES: 1129 vanilla records (maps $000-$1FF) + 0 content records; 513 pointers |
| M104_MAPX_LONG_ENTRANCES | 370000–370829 | F7:0000–F7:0829 | 2090 | `FF fill (expansion)` | `<2090 bytes, sha1 f51157f2bcb62c06ce4a30d372a0565f7038031d>` | 19 retargeted consumers — LONG_ENTRANCES: 152 vanilla records (maps $000-$1FF) + 0 content records; 513 pointers |
| M105_MAPX_TREASURE | 372000–372997 | F7:2000–F7:2997 | 2456 | `FF fill (expansion)` | `<2456 bytes, sha1 da3999f9095378d1e09f048ecd0039465600bed1>` | 12 retargeted consumers — TREASURE: 286 vanilla records (maps $000-$19E) + 0 content records; 513 pointers |
| M106_MAPX_MAP_PROPS | 374000–3781FF | F7:4000–F7:81FF | 16896 | `FF fill (expansion)` | `<16896 bytes, sha1 9a0c0f9fe2c62d950a1737e5fdd6e2d51590e779>` | LoadMapProp C0:1CAD (LDA.l MapProp,X; X = map*33) — 512 x 33-byte rows: vanilla $000-$19E copied; content rows [] |
| M107_MAPX_SUBTILEMAP_PTRS | 378400–378FFF | F7:8400–F7:8FFF | 3072 | `FF fill (expansion)` | `<3072 bytes, sha1 19092144eb825e13585f0dd061634c7ac31a0d1f>` | LoadMapTiles C0:2883 (BG1/BG2/BG3, 10-bit index * 3) — 1024 layout pointers: vanilla $000-$15E copied, unassigned = entry $000 value; content [] |
| M200_RETARGET_EVENT_TRIGGERS | 00BCAF–00BCB1 | C0:BCAF–C0:BCB1 | 3 | `02 00 C4` | `02 00 F6` | C0:BCAE opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCB5–00BCB7 | C0:BCB5–C0:BCB7 | 3 | `00 00 C4` | `00 00 F6` | C0:BCB4 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCBE–00BCC0 | C0:BCBE–C0:BCC0 | 3 | `00 00 C4` | `00 00 F6` | C0:BCBD opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCD4–00BCD6 | C0:BCD4–C0:BCD6 | 3 | `02 00 C4` | `02 00 F6` | C0:BCD3 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCEE–00BCF0 | C0:BCEE–C0:BCF0 | 3 | `04 00 C4` | `04 00 F6` | C0:BCED opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0004 -> F6:0004 (ptr base + 4) |
| M200_RETARGET_EVENT_TRIGGERS | 2E2177–2E2179 | EE:2177–EE:2179 | 3 | `00 00 C4` | `00 00 F6` | EE:2176 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 2E217D–2E217F | EE:217D–EE:217F | 3 | `02 00 C4` | `02 00 F6` | EE:217C opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 2E218C–2E218E | EE:218C–EE:218E | 3 | `00 00 C4` | `00 00 F6` | EE:218B opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 2E2194–2E2196 | EE:2194–EE:2196 | 3 | `01 00 C4` | `01 00 F6` | EE:2193 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0001 -> F6:0001 (ptr base + 1) |
| M200_RETARGET_EVENT_TRIGGERS | 2E219C–2E219E | EE:219C–EE:219E | 3 | `02 00 C4` | `02 00 F6` | EE:219B opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 2E21A5–2E21A7 | EE:21A5–EE:21A7 | 3 | `03 00 C4` | `03 00 F6` | EE:21A4 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0003 -> F6:0003 (ptr base + 3) |
| M200_RETARGET_EVENT_TRIGGERS | 2E21AD–2E21AF | EE:21AD–EE:21AF | 3 | `04 00 C4` | `04 00 F6` | EE:21AC opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0004 -> F6:0004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 0052BD–0052BF | C0:52BD–C0:52BF | 3 | `12 1A C4` | `02 40 F6` | C0:52BC opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052C3–0052C5 | C0:52C3–C0:52C5 | 3 | `10 1A C4` | `00 40 F6` | C0:52C2 opcode BF (long,X) reads NPC_PROPS — operand C4:1A10 -> F6:4000 (ptr base + 0) |
| M200_RETARGET_NPC_PROPS | 0052D5–0052D7 | C0:52D5–C0:52D7 | 3 | `10 1A C4` | `00 40 F6` | C0:52D4 opcode BF (long,X) reads NPC_PROPS — operand C4:1A10 -> F6:4000 (ptr base + 0) |
| M200_RETARGET_NPC_PROPS | 0052DC–0052DE | C0:52DC–C0:52DE | 3 | `11 1A C4` | `01 40 F6` | C0:52DB opcode BF (long,X) reads NPC_PROPS — operand C4:1A11 -> F6:4001 (ptr base + 1) |
| M200_RETARGET_NPC_PROPS | 0052E3–0052E5 | C0:52E3–C0:52E5 | 3 | `12 1A C4` | `02 40 F6` | C0:52E2 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052EC–0052EE | C0:52EC–C0:52EE | 3 | `12 1A C4` | `02 40 F6` | C0:52EB opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052F9–0052FB | C0:52F9–C0:52FB | 3 | `12 1A C4` | `02 40 F6` | C0:52F8 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 005306–005308 | C0:5306–C0:5308 | 3 | `12 1A C4` | `02 40 F6` | C0:5305 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 005322–005324 | C0:5322–C0:5324 | 3 | `14 1A C4` | `04 40 F6` | C0:5321 opcode BF (long,X) reads NPC_PROPS — operand C4:1A14 -> F6:4004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 00532D–00532F | C0:532D–C0:532F | 3 | `14 1A C4` | `04 40 F6` | C0:532C opcode BF (long,X) reads NPC_PROPS — operand C4:1A14 -> F6:4004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 00533B–00533D | C0:533B–C0:533D | 3 | `15 1A C4` | `05 40 F6` | C0:533A opcode BF (long,X) reads NPC_PROPS — operand C4:1A15 -> F6:4005 (ptr base + 5) |
| M200_RETARGET_NPC_PROPS | 00535B–00535D | C0:535B–C0:535D | 3 | `15 1A C4` | `05 40 F6` | C0:535A opcode BF (long,X) reads NPC_PROPS — operand C4:1A15 -> F6:4005 (ptr base + 5) |
| M200_RETARGET_NPC_PROPS | 00536A–00536C | C0:536A–C0:536C | 3 | `16 1A C4` | `06 40 F6` | C0:5369 opcode BF (long,X) reads NPC_PROPS — operand C4:1A16 -> F6:4006 (ptr base + 6) |
| M200_RETARGET_NPC_PROPS | 005374–005376 | C0:5374–C0:5376 | 3 | `17 1A C4` | `07 40 F6` | C0:5373 opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 005380–005382 | C0:5380–C0:5382 | 3 | `17 1A C4` | `07 40 F6` | C0:537F opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 00538B–00538D | C0:538B–C0:538D | 3 | `17 1A C4` | `07 40 F6` | C0:538A opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 005398–00539A | C0:5398–C0:539A | 3 | `18 1A C4` | `08 40 F6` | C0:5397 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053AE–0053B0 | C0:53AE–C0:53B0 | 3 | `18 1A C4` | `08 40 F6` | C0:53AD opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053BD–0053BF | C0:53BD–C0:53BF | 3 | `18 1A C4` | `08 40 F6` | C0:53BC opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053D1–0053D3 | C0:53D1–C0:53D3 | 3 | `18 1A C4` | `08 40 F6` | C0:53D0 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053E4–0053E6 | C0:53E4–C0:53E6 | 3 | `18 1A C4` | `08 40 F6` | C0:53E3 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_SHORT_ENTRANCES | 001A7E–001A80 | C0:1A7E–C0:1A80 | 3 | `02 BB DF` | `02 C0 F6` | C0:1A7D opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001A84–001A86 | C0:1A84–C0:1A86 | 3 | `00 BB DF` | `00 C0 F6` | C0:1A83 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 001A90–001A92 | C0:1A90–C0:1A92 | 3 | `00 BB DF` | `00 C0 F6` | C0:1A8F opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 001AAB–001AAD | C0:1AAB–C0:1AAD | 3 | `02 BB DF` | `02 C0 F6` | C0:1AAA opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AB7–001AB9 | C0:1AB7–C0:1AB9 | 3 | `02 BB DF` | `02 C0 F6` | C0:1AB6 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AC3–001AC5 | C0:1AC3–C0:1AC5 | 3 | `02 BB DF` | `02 C0 F6` | C0:1AC2 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AD2–001AD4 | C0:1AD2–C0:1AD4 | 3 | `04 BB DF` | `04 C0 F6` | C0:1AD1 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_SHORT_ENTRANCES | 001AE7–001AE9 | C0:1AE7–C0:1AE9 | 3 | `04 BB DF` | `04 C0 F6` | C0:1AE6 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_SHORT_ENTRANCES | 001AF1–001AF3 | C0:1AF1–C0:1AF3 | 3 | `03 BB DF` | `03 C0 F6` | C0:1AF0 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001AFE–001B00 | C0:1AFE–C0:1B00 | 3 | `03 BB DF` | `03 C0 F6` | C0:1AFD opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001B0C–001B0E | C0:1B0C–C0:1B0E | 3 | `03 BB DF` | `03 C0 F6` | C0:1B0B opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001B2D–001B2F | C0:1B2D–C0:1B2F | 3 | `02 BB DF` | `02 C0 F6` | C0:1B2C opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001B5F–001B61 | C0:1B5F–C0:1B61 | 3 | `03 BB DF` | `03 C0 F6` | C0:1B5E opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20EA–2E20EC | EE:20EA–EE:20EC | 3 | `00 BB DF` | `00 C0 F6` | EE:20E9 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20F0–2E20F2 | EE:20F0–EE:20F2 | 3 | `02 BB DF` | `02 C0 F6` | EE:20EF opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20FF–2E2101 | EE:20FF–EE:2101 | 3 | `00 BB DF` | `00 C0 F6` | EE:20FE opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 2E2107–2E2109 | EE:2107–EE:2109 | 3 | `01 BB DF` | `01 C0 F6` | EE:2106 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB01 -> F6:C001 (ptr base + 1) |
| M200_RETARGET_SHORT_ENTRANCES | 2E2111–2E2113 | EE:2111–EE:2113 | 3 | `02 BB DF` | `02 C0 F6` | EE:2110 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 2E213D–2E213F | EE:213D–EE:213F | 3 | `04 BB DF` | `04 C0 F6` | EE:213C opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0018EB–0018ED | C0:18EB–C0:18ED | 3 | `82 F4 ED` | `02 00 F7` | C0:18EA opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F482 -> F7:0002 (ptr base + 2) |
| M200_RETARGET_LONG_ENTRANCES | 0018F1–0018F3 | C0:18F1–C0:18F3 | 3 | `80 F4 ED` | `00 00 F7` | C0:18F0 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 001904–001906 | C0:1904–C0:1906 | 3 | `82 F4 ED` | `02 00 F7` | C0:1903 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F482 -> F7:0002 (ptr base + 2) |
| M200_RETARGET_LONG_ENTRANCES | 00190C–00190E | C0:190C–C0:190E | 3 | `81 F4 ED` | `01 00 F7` | C0:190B opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001917–001919 | C0:1917–C0:1919 | 3 | `80 F4 ED` | `00 00 F7` | C0:1916 opcode FF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 00191F–001921 | C0:191F–C0:1921 | 3 | `80 F4 ED` | `00 00 F7` | C0:191E opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 001930–001932 | C0:1930–C0:1932 | 3 | `80 F4 ED` | `00 00 F7` | C0:192F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 00193B–00193D | C0:193B–C0:193D | 3 | `81 F4 ED` | `01 00 F7` | C0:193A opcode FF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001943–001945 | C0:1943–C0:1945 | 3 | `81 F4 ED` | `01 00 F7` | C0:1942 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001964–001966 | C0:1964–C0:1966 | 3 | `83 F4 ED` | `03 00 F7` | C0:1963 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 001970–001972 | C0:1970–C0:1972 | 3 | `83 F4 ED` | `03 00 F7` | C0:196F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 00197C–00197E | C0:197C–C0:197E | 3 | `83 F4 ED` | `03 00 F7` | C0:197B opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 00198B–00198D | C0:198B–C0:198D | 3 | `85 F4 ED` | `05 00 F7` | C0:198A opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F485 -> F7:0005 (ptr base + 5) |
| M200_RETARGET_LONG_ENTRANCES | 0019A0–0019A2 | C0:19A0–C0:19A2 | 3 | `85 F4 ED` | `05 00 F7` | C0:199F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F485 -> F7:0005 (ptr base + 5) |
| M200_RETARGET_LONG_ENTRANCES | 0019AA–0019AC | C0:19AA–C0:19AC | 3 | `84 F4 ED` | `04 00 F7` | C0:19A9 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019B7–0019B9 | C0:19B7–C0:19B9 | 3 | `84 F4 ED` | `04 00 F7` | C0:19B6 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019C5–0019C7 | C0:19C5–C0:19C7 | 3 | `84 F4 ED` | `04 00 F7` | C0:19C4 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019E6–0019E8 | C0:19E6–C0:19E8 | 3 | `83 F4 ED` | `03 00 F7` | C0:19E5 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 001A15–001A17 | C0:1A15–C0:1A17 | 3 | `84 F4 ED` | `04 00 F7` | C0:1A14 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_TREASURE | 0015DE–0015E0 | C0:15DE–C0:15E0 | 3 | `F6 82 ED` | `02 20 F7` | C0:15DD opcode BF (long,X) reads TREASURE — operand ED:82F6 -> F7:2002 (ptr base + 2) |
| M200_RETARGET_TREASURE | 0015E4–0015E6 | C0:15E4–C0:15E6 | 3 | `F4 82 ED` | `00 20 F7` | C0:15E3 opcode BF (long,X) reads TREASURE — operand ED:82F4 -> F7:2000 (ptr base + 0) |
| M200_RETARGET_TREASURE | 0015F2–0015F4 | C0:15F2–C0:15F4 | 3 | `34 86 ED` | `02 24 F7` | C0:15F1 opcode BF (long,X) reads TREASURE — operand ED:8634 -> F7:2402 (data base + 0) |
| M200_RETARGET_TREASURE | 0015F8–0015FA | C0:15F8–C0:15FA | 3 | `35 86 ED` | `03 24 F7` | C0:15F7 opcode BF (long,X) reads TREASURE — operand ED:8635 -> F7:2403 (data base + 1) |
| M200_RETARGET_TREASURE | 0015FF–001601 | C0:15FF–C0:1601 | 3 | `36 86 ED` | `04 24 F7` | C0:15FE opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_TREASURE | 00160A–00160C | C0:160A–C0:160C | 3 | `36 86 ED` | `04 24 F7` | C0:1609 opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_TREASURE | 004BDB–004BDD | C0:4BDB–C0:4BDD | 3 | `F6 82 ED` | `02 20 F7` | C0:4BDA opcode BF (long,X) reads TREASURE — operand ED:82F6 -> F7:2002 (ptr base + 2) |
| M200_RETARGET_TREASURE | 004BE1–004BE3 | C0:4BE1–C0:4BE3 | 3 | `F4 82 ED` | `00 20 F7` | C0:4BE0 opcode BF (long,X) reads TREASURE — operand ED:82F4 -> F7:2000 (ptr base + 0) |
| M200_RETARGET_TREASURE | 004BED–004BEF | C0:4BED–C0:4BEF | 3 | `34 86 ED` | `02 24 F7` | C0:4BEC opcode BF (long,X) reads TREASURE — operand ED:8634 -> F7:2402 (data base + 0) |
| M200_RETARGET_TREASURE | 004BF5–004BF7 | C0:4BF5–C0:4BF7 | 3 | `35 86 ED` | `03 24 F7` | C0:4BF4 opcode BF (long,X) reads TREASURE — operand ED:8635 -> F7:2403 (data base + 1) |
| M200_RETARGET_TREASURE | 004C09–004C0B | C0:4C09–C0:4C0B | 3 | `38 86 ED` | `06 24 F7` | C0:4C08 opcode BF (long,X) reads TREASURE — operand ED:8638 -> F7:2406 (data base + 4) |
| M200_RETARGET_TREASURE | 004C0F–004C11 | C0:4C0F–C0:4C11 | 3 | `36 86 ED` | `04 24 F7` | C0:4C0E opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_MAP_PROPS | 001CC0–001CC2 | C0:1CC0–C0:1CC2 | 3 | `00 8F ED` | `00 40 F7` | C0:1CBF opcode BF (long,X) reads MAP_PROPS — operand ED:8F00 -> F7:4000 (data base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 002893–002895 | C0:2893–C0:2895 | 3 | `90 CD D9` | `00 84 F7` | C0:2892 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028A0–0028A2 | C0:28A0–C0:28A2 | 3 | `92 CD D9` | `02 84 F7` | C0:289F opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028E7–0028E9 | C0:28E7–C0:28E9 | 3 | `90 CD D9` | `00 84 F7` | C0:28E6 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028F4–0028F6 | C0:28F4–C0:28F6 | 3 | `92 CD D9` | `02 84 F7` | C0:28F3 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M200_RETARGET_SUBTILEMAP_PTRS | 00293D–00293F | C0:293D–C0:293F | 3 | `90 CD D9` | `00 84 F7` | C0:293C opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 00294A–00294C | C0:294A–C0:294C | 3 | `92 CD D9` | `02 84 F7` | C0:2949 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M300_NPC_EVENT_ROUTER | 301100–301146 | F0:1100–F0:1146 | 71 | `FF fill (expansion)` | `29 03 C9 03 D0 3D BF 04 40 F6 30 35 C2 20 B9 89 08 C9 00 …` | JSL from C0:52E6 (InitNPCs) — NPC event router: vanilla NPCs unchanged; non-special NPCs with event field $3xxxx -> vector table |
| M300_NPC_EVENT_ROUTER | 0052E6–0052EA | C0:52E6–C0:52EA | 5 | `29 03 99 8B 08` | `22 00 11 F0 EA` | InitNPCs C0:52E6 (after LDA NPCProp::EventPtr+2,X) — AND #$03 / STA $088B,Y -> JSL F0:1100 / NOP (router re-executes both for vanilla NPCs) |
| N101_MONSTER_PROP | 380000–383FFF | F8:0000–F8:3FFF | 16384 | `FF fill (expansion)` | `<16384 bytes, sha1 e2189a7df88e41678434cf0ee3afdfa24b98d9a2>` | 25 retargeted consumers — MONSTER_PROP relocated (16384 bytes); vanilla entries byte-identical; content: none |
| N102_MONSTER_NAME | 384000–3853FF | F8:4000–F8:53FF | 5120 | `FF fill (expansion)` | `<5120 bytes, sha1 63ace3d6076452374a17b6977d912f653d354ac9>` | 6 retargeted consumers — MONSTER_NAME relocated (5120 bytes); vanilla entries byte-identical; content: none |
| N103_MONSTER_SPECIAL_NAME | 385400–3867FF | F8:5400–F8:67FF | 5120 | `FF fill (expansion)` | `<5120 bytes, sha1 4bfabfe48907716a893c9797a2c4dbc197285b0a>` | 2 retargeted consumers — MONSTER_SPECIAL_NAME relocated (5120 bytes); vanilla entries byte-identical; content: none |
| N104_MONSTER_ITEMS | 386800–386FFF | F8:6800–F8:6FFF | 2048 | `FF fill (expansion)` | `<2048 bytes, sha1 91c840de78fafd5f706b5e85e99ba5dbc4d265c0>` | 2 retargeted consumers — MONSTER_ITEMS relocated (2048 bytes); vanilla entries byte-identical; content: none |
| N105_MONSTER_CONTROL | 387000–3877FF | F8:7000–F8:77FF | 2048 | `FF fill (expansion)` | `<2048 bytes, sha1 53f8640cb48680626d6852f8c9f37cf4e513c5fa>` | 3 retargeted consumers — MONSTER_CONTROL relocated (2048 bytes); vanilla entries byte-identical; content: none |
| N106_MONSTER_SKETCH | 387800–387BFF | F8:7800–F8:7BFF | 1024 | `FF fill (expansion)` | `<1024 bytes, sha1 c6bce88dfd9d3b1f2e5e8896a1732a59f6a581c2>` | 1 retargeted consumers — MONSTER_SKETCH relocated (1024 bytes); vanilla entries byte-identical; content: none |
| N107_MONSTER_SPECIAL_ANIM | 387C00–387DFF | F8:7C00–F8:7DFF | 512 | `FF fill (expansion)` | `03 03 0D 18 07 0E 1B 21 0C 10 0B 0C 0C 00 1C 0E 12 0B 15 …` | 2 retargeted consumers — MONSTER_SPECIAL_ANIM relocated (512 bytes); vanilla entries byte-identical; content: none |
| N108_MONSTER_OVERLAP | 387E00–387FFF | F8:7E00–F8:7FFF | 512 | `FF fill (expansion)` | `00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 …` | 1 retargeted consumers — MONSTER_OVERLAP relocated (512 bytes); vanilla entries byte-identical; content: none |
| N109_MONSTER_GFX_PROP | 388000–388A9A | F8:8000–F8:8A9A | 2715 | `FF fill (expansion)` | `<2715 bytes, sha1 ba2bb9ebfe25e37a30e1e0de01f095e586144e08>` | 15 retargeted consumers — MONSTER_GFX_PROP relocated (2715 bytes); vanilla entries byte-identical; content: none |
| N112_AI_SCRIPT_PTRS | 390000–3903FF | F9:0000–F9:03FF | 1024 | `FF fill (expansion)` | `<1024 bytes, sha1 9bb0dba2928867b36b37f61a485c5aadaecad6d6>` | 1 retargeted consumers — AI_SCRIPT_PTRS relocated (1024 bytes); vanilla entries byte-identical; content: none |
| N113_AI_SCRIPT | 390400–393D51 | F9:0400–F9:3D51 | 14674 | `FF fill (expansion)` | `<14674 bytes, sha1 d6b9bbb4dccd2bd18a9b7d96c8ee5b895043f702>` | 4 retargeted consumers — AI_SCRIPT relocated (14674 bytes); vanilla entries byte-identical; content: none |
| N110_FORMATION_PROP | 389000–389FFF | F8:9000–F8:9FFF | 4096 | `FF fill (expansion)` | `<4096 bytes, sha1 8e1b7022fc90788852585cc42cfb43396b27e291>` | 2 retargeted consumers — FORMATION_PROP relocated (4096 bytes); vanilla entries byte-identical; content: none |
| N111_FORMATION_MONSTERS | 38A000–38DC0F | F8:A000–F8:DC0F | 15376 | `FF fill (expansion)` | `<15376 bytes, sha1 0f85b8c489c32aaed89f011d78ca7da9feb53ad8>` | 7 retargeted consumers — FORMATION_MONSTERS relocated (15376 bytes); vanilla entries byte-identical; content: none |
| N200_RETARGET_MONSTER_PROP | 020626–020628 | C2:0626–C2:0628 | 3 | `1A 00 CF` | `1A 00 F8` | C2:0625 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 26 |
| N200_RETARGET_MONSTER_PROP | 022CA4–022CA6 | C2:2CA4–C2:2CA6 | 3 | `05 00 CF` | `05 00 F8` | C2:2CA3 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 5 |
| N200_RETARGET_MONSTER_PROP | 022CAB–022CAD | C2:2CAB–C2:2CAD | 3 | `0C 00 CF` | `0C 00 F8` | C2:2CAA opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 12 |
| N200_RETARGET_MONSTER_PROP | 022CB2–022CB4 | C2:2CB2–C2:2CB4 | 3 | `0E 00 CF` | `0E 00 F8` | C2:2CB1 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 14 |
| N200_RETARGET_MONSTER_PROP | 022CBE–022CC0 | C2:2CBE–C2:2CC0 | 3 | `0A 00 CF` | `0A 00 F8` | C2:2CBD opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 10 |
| N200_RETARGET_MONSTER_PROP | 022CC8–022CCA | C2:2CC8–C2:2CCA | 3 | `08 00 CF` | `08 00 F8` | C2:2CC7 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 8 |
| N200_RETARGET_MONSTER_PROP | 022CF6–022CF8 | C2:2CF6–C2:2CF8 | 3 | `01 00 CF` | `01 00 F8` | C2:2CF5 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 1 |
| N200_RETARGET_MONSTER_PROP | 022CFD–022CFF | C2:2CFD–C2:2CFF | 3 | `1A 00 CF` | `1A 00 F8` | C2:2CFC opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 26 |
| N200_RETARGET_MONSTER_PROP | 022D04–022D06 | C2:2D04–C2:2D06 | 3 | `03 00 CF` | `03 00 F8` | C2:2D03 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 3 |
| N200_RETARGET_MONSTER_PROP | 022D0E–022D10 | C2:2D0E–C2:2D10 | 3 | `04 00 CF` | `04 00 F8` | C2:2D0D opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 4 |
| N200_RETARGET_MONSTER_PROP | 022D18–022D1A | C2:2D18–C2:2D1A | 3 | `02 00 CF` | `02 00 F8` | C2:2D17 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 2 |
| N200_RETARGET_MONSTER_PROP | 022D1F–022D21 | C2:2D1F–C2:2D21 | 3 | `10 00 CF` | `10 00 F8` | C2:2D1E opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 16 |
| N200_RETARGET_MONSTER_PROP | 022D26–022D28 | C2:2D26–C2:2D28 | 3 | `00 00 CF` | `00 00 F8` | C2:2D25 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 0 |
| N200_RETARGET_MONSTER_PROP | 022D2D–022D2F | C2:2D2D–C2:2D2F | 3 | `07 00 CF` | `07 00 F8` | C2:2D2C opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 7 |
| N200_RETARGET_MONSTER_PROP | 022D37–022D39 | C2:2D37–C2:2D39 | 3 | `1E 00 CF` | `1E 00 F8` | C2:2D36 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 30 |
| N200_RETARGET_MONSTER_PROP | 022D43–022D45 | C2:2D43–C2:2D45 | 3 | `13 00 CF` | `13 00 F8` | C2:2D42 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 19 |
| N200_RETARGET_MONSTER_PROP | 022DC3–022DC5 | C2:2DC3–C2:2DC5 | 3 | `1F 00 CF` | `1F 00 F8` | C2:2DC2 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 31 |
| N200_RETARGET_MONSTER_PROP | 022DCA–022DCC | C2:2DCA–C2:2DCC | 3 | `19 00 CF` | `19 00 F8` | C2:2DC9 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 25 |
| N200_RETARGET_MONSTER_PROP | 022DD4–022DD6 | C2:2DD4–C2:2DD6 | 3 | `16 00 CF` | `16 00 F8` | C2:2DD3 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 22 |
| N200_RETARGET_MONSTER_PROP | 022DEA–022DEC | C2:2DEA–C2:2DEC | 3 | `1B 00 CF` | `1B 00 F8` | C2:2DE9 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 27 |
| N200_RETARGET_MONSTER_PROP | 022DF1–022DF3 | C2:2DF1–C2:2DF3 | 3 | `1D 00 CF` | `1D 00 F8` | C2:2DF0 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 29 |
| N200_RETARGET_MONSTER_PROP | 022E11–022E13 | C2:2E11–C2:2E13 | 3 | `1C 00 CF` | `1C 00 F8` | C2:2E10 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 28 |
| N200_RETARGET_MONSTER_PROP | 022E1B–022E1D | C2:2E1B–C2:2E1D | 3 | `14 00 CF` | `14 00 F8` | C2:2E1A opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 20 |
| N200_RETARGET_MONSTER_PROP | 022E28–022E2A | C2:2E28–C2:2E2A | 3 | `17 00 CF` | `17 00 F8` | C2:2E27 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 23 |
| N200_RETARGET_MONSTER_PROP | 022E32–022E34 | C2:2E32–C2:2E34 | 3 | `11 00 CF` | `11 00 F8` | C2:2E31 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 17 |
| N200_RETARGET_MONSTER_NAME | 016641–016643 | C1:6641–C1:6643 | 3 | `50 C0 CF` | `00 40 F8` | C1:6640 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 0169C7–0169C9 | C1:69C7–C1:69C9 | 3 | `50 C0 CF` | `00 40 F8` | C1:69C6 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 022C57–022C59 | C2:2C57–C2:2C59 | 3 | `50 C0 CF` | `00 40 F8` | C2:2C56 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 022C79–022C7B | C2:2C79–C2:2C7B | 3 | `50 C0 CF` | `00 40 F8` | C2:2C78 opcode DF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 03540F–035410 | C3:540F–C3:5410 | 2 | `50 C0` | `00 40` | C3:540E opcode A0 (imm_near) reads MONSTER_NAME — imm_near operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 035414–035414 | C3:5414–C3:5414 | 1 | `CF` | `F8` | C3:5413 opcode A9 (imm_bank) reads MONSTER_NAME — imm_bank operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_NAME | 019739–019739 | C1:9739–C1:9739 | 1 | `CF` | `F8` | C1:9738 opcode A9 (imm_bank) reads MONSTER_SPECIAL_NAME — imm_bank operand -> F8:5400 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_NAME | 01974D–01974E | C1:974D–C1:974E | 2 | `D0 D0` | `00 54` | C1:974C opcode 69 (imm_near) reads MONSTER_SPECIAL_NAME — imm_near operand -> F8:5400 + 0 |
| N200_RETARGET_MONSTER_ITEMS | 022C42–022C44 | C2:2C42–C2:2C44 | 3 | `00 30 CF` | `00 68 F8` | C2:2C41 opcode BF (long) reads MONSTER_ITEMS — long operand -> F8:6800 + 0 |
| N200_RETARGET_MONSTER_ITEMS | 025F2E–025F30 | C2:5F2E–C2:5F30 | 3 | `02 30 CF` | `02 68 F8` | C2:5F2D opcode BF (long) reads MONSTER_ITEMS — long operand -> F8:6800 + 2 |
| N200_RETARGET_MONSTER_CONTROL | 02063E–020640 | C2:063E–C2:0640 | 3 | `00 3D CF` | `00 70 F8` | C2:063D opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 0 |
| N200_RETARGET_MONSTER_CONTROL | 020644–020646 | C2:0644–C2:0646 | 3 | `02 3D CF` | `02 70 F8` | C2:0643 opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 2 |
| N200_RETARGET_MONSTER_CONTROL | 023759–02375B | C2:3759–C2:375B | 3 | `00 3D CF` | `00 70 F8` | C2:3758 opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 0 |
| N200_RETARGET_MONSTER_SKETCH | 023B5B–023B5D | C2:3B5B–C2:3B5D | 3 | `00 43 CF` | `00 78 F8` | C2:3B5A opcode BF (long) reads MONSTER_SKETCH — long operand -> F8:7800 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_ANIM | 020617–020619 | C2:0617–C2:0619 | 3 | `C0 37 CF` | `00 7C F8` | C2:0616 opcode BF (long) reads MONSTER_SPECIAL_ANIM — long operand -> F8:7C00 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_ANIM | 022D50–022D52 | C2:2D50–C2:2D52 | 3 | `C0 37 CF` | `00 7C F8` | C2:2D4F opcode BF (long) reads MONSTER_SPECIAL_ANIM — long operand -> F8:7C00 + 0 |
| N200_RETARGET_MONSTER_OVERLAP | 012145–012147 | C1:2145–C1:2147 | 3 | `00 36 CF` | `00 7E F8` | C1:2144 opcode BF (long) reads MONSTER_OVERLAP — long operand -> F8:7E00 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 012063–012065 | C1:2063–C1:2065 | 3 | `02 70 D2` | `02 80 F8` | C1:2062 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 012081–012083 | C1:2081–C1:2083 | 3 | `00 70 D2` | `00 80 F8` | C1:2080 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 01208E–012090 | C1:208E–C1:2090 | 3 | `01 70 D2` | `01 80 F8` | C1:208D opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 012097–012099 | C1:2097–C1:2099 | 3 | `02 70 D2` | `02 80 F8` | C1:2096 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 0120AC–0120AE | C1:20AC–C1:20AE | 3 | `04 70 D2` | `04 80 F8` | C1:20AB opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_MONSTER_GFX_PROP | 0124FD–0124FF | C1:24FD–C1:24FF | 3 | `02 70 D2` | `02 80 F8` | C1:24FC opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 01250C–01250E | C1:250C–C1:250E | 3 | `00 70 D2` | `00 80 F8` | C1:250B opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 012519–01251B | C1:2519–C1:251B | 3 | `01 70 D2` | `01 80 F8` | C1:2518 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 012522–012524 | C1:2522–C1:2524 | 3 | `02 70 D2` | `02 80 F8` | C1:2521 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 012537–012539 | C1:2537–C1:2539 | 3 | `04 70 D2` | `04 80 F8` | C1:2536 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF60–03AF62 | C3:AF60–C3:AF62 | 3 | `00 70 D2` | `00 80 F8` | C3:AF5F opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF66–03AF68 | C3:AF66–C3:AF68 | 3 | `01 70 D2` | `01 80 F8` | C3:AF65 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF6C–03AF6E | C3:AF6C–C3:AF6E | 3 | `02 70 D2` | `02 80 F8` | C3:AF6B opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF72–03AF74 | C3:AF72–C3:AF74 | 3 | `03 70 D2` | `03 80 F8` | C3:AF71 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 3 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF78–03AF7A | C3:AF78–C3:AF7A | 3 | `04 70 D2` | `04 80 F8` | C3:AF77 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_AI_SCRIPT_PTRS | 022D79–022D7B | C2:2D79–C2:2D7B | 3 | `00 84 CF` | `00 00 F9` | C2:2D78 opcode BF (long) reads AI_SCRIPT_PTRS — long operand -> F9:0000 + 0 |
| N200_RETARGET_AI_SCRIPT | 021A45–021A47 | C2:1A45–C2:1A47 | 3 | `00 87 CF` | `00 04 F9` | C2:1A44 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_AI_SCRIPT | 021A65–021A67 | C2:1A65–C2:1A67 | 3 | `02 87 CF` | `02 04 F9` | C2:1A64 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 2 |
| N200_RETARGET_AI_SCRIPT | 021A6C–021A6E | C2:1A6C–C2:1A6E | 3 | `00 87 CF` | `00 04 F9` | C2:1A6B opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_AI_SCRIPT | 022D89–022D8B | C2:2D89–C2:2D8B | 3 | `00 87 CF` | `00 04 F9` | C2:2D88 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_FORMATION_PROP | 023137–023139 | C2:3137–C2:3139 | 3 | `02 59 CF` | `02 90 F8` | C2:3136 opcode BF (long) reads FORMATION_PROP — long operand -> F8:9000 + 2 |
| N200_RETARGET_FORMATION_PROP | 02313E–023140 | C2:313E–C2:3140 | 3 | `00 59 CF` | `00 90 F8` | C2:313D opcode BF (long) reads FORMATION_PROP — long operand -> F8:9000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010E9A–010E9C | C1:0E9A–C1:0E9C | 3 | `0E 62 CF` | `0E A0 F8` | C1:0E99 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 14 |
| N200_RETARGET_FORMATION_MONSTERS | 010EA2–010EA4 | C1:0EA2–C1:0EA4 | 3 | `00 62 CF` | `00 A0 F8` | C1:0EA1 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010EB5–010EB7 | C1:0EB5–C1:0EB7 | 3 | `00 62 CF` | `00 A0 F8` | C1:0EB4 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010EC0–010EC2 | C1:0EC0–C1:0EC2 | 3 | `01 62 CF` | `01 A0 F8` | C1:0EBF opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 1 |
| N200_RETARGET_FORMATION_MONSTERS | 010ED2–010ED4 | C1:0ED2–C1:0ED4 | 3 | `08 62 CF` | `08 A0 F8` | C1:0ED1 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 8 |
| N200_RETARGET_FORMATION_MONSTERS | 010EE0–010EE2 | C1:0EE0–C1:0EE2 | 3 | `08 62 CF` | `08 A0 F8` | C1:0EDF opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 8 |
| N200_RETARGET_FORMATION_MONSTERS | 023156–023158 | C2:3156–C2:3158 | 3 | `00 62 CF` | `00 A0 F8` | C2:3155 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N300_GFX_SLOT_ROUTERS | 301200–301230 | F0:1200–F0:1230 | 49 | `FF fill (expansion)` | `BD 01 20 C9 80 01 90 03 69 1F 00 48 0A 0A 18 63 01 FA 6B …` | JSL from C1:2058 (battle monster loader), C2:F5F1 (Sketch), C2:2F75 (colosseum detection) — graphics-property slot remap (monsters $180-$1FE -> slots $1A0-$21E) + colosseum range check |
| N301_GFX_SLOT_HOOK_BATTLE | 012058–012060 | C1:2058–C1:2060 | 9 | `BD 01 20 0A 0A 18 7D 01 20` | `22 00 12 F0 EA EA EA EA EA` | LoadMonsterGfxProp (C1:204E) monster id*5 computation — LDA $2001,X/ASL/ASL/CLC/ADC $2001,X -> JSL MonsterGfxSlot5 + 5x NOP |
| N302_GFX_SLOT_HOOK_SKETCH | 02F5F1–02F5F4 | C2:F5F1–C2:F5F4 | 4 | `BD 01 20 AA` | `22 13 12 F0` | battle animation init $0B (Sketch): monster id -> LoadSketchMonsterGfx — LDA $2001,X/TAX -> JSL MonsterGfxSlotSketch |
| N303_FORMATION_COLOSSEUM_RANGE | 022F75–022F7A | C2:2F75–C2:2F7A | 6 | `AE D4 3E E0 3E 02` | `22 20 12 F0 EA EA` | InitParty C2:2F75 colosseum detection (battle id >= $23E) — LDX wBattleID/CPX #$023E -> JSL ColosseumRangeCheck + 2x NOP; colosseum iff $23E <= id < $240 so new formations $240-$3FF load normally |
| P999_CHECKSUM | 00FFDC–00FFDF | C0:FFDC–C0:FFDF | 4 | `9F 75 60 8A` | `66 1C 99 E3` | SNES header (emulator/flash-cart validation) — Recalculated checksum E399 / complement 1C66 |

## monster-tech — `FF6X_Rev1_TECH_v0.5.0_MONSTER_TECH_QA.sfc`

SHA-1 `416d5d9fbd88751e8fbd5ab4290dbb51fff3e69f` · CRC32 `381E6EE5` · SNES checksum `AC44` · status: TECH v0.5 QA BUILD = celes-tech v0.5 + v0.4 proof maps + QA monsters $180/$181 + QA formation $240 + QA access (QA parts Q5xx)

| ID | PC | SNES | Len | Original | New | Consumer / reason |
|---|---|---|---|---|---|---|
| P000_EXPAND_4MIB | 300000–3FFFFF | F0:0000–FF:FFFF | 1048576 | `` | `FF fill` | All F0-FF expansion allocations. — Expand 3 MiB -> 4 MiB HiROM. Header ROM-size byte C0:FFD7 is already 0x0C (4 MiB class) in Rev 1; unchanged. |
| P001_BUILD_METADATA | 300000–30003F | F0:0000–F0:003F | 64 | `FF fill (expansion)` | `46 46 36 58 2D 45 45 00 01 00 05 00 00 02 00 00 6D 6F 6E …` | tools/verify (offline). No runtime consumer. — Machine-readable build identity for QA tooling. |
| P101_EXP_DLG_TABLE | 334000–33402A | F3:4000–F3:402A | 43 | `FF fill (expansion)` | `24 37 2F 20 2D 32 28 2E 2D 7F 23 28 20 2B 2E 26 34 24 7F …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1000: 'EXPANSION DIALOGUE ERROR:{n}ID OUT OF RANGE.' |
| P101_EXP_DLG_TABLE | 33402B–334061 | F3:402B–F3:4061 | 55 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 57 61 7F 20 47 47 3E 51 7F 4D 3E …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1001: 'TECH v0.3: Annex test map.{n}Enter the Annex?{n}{choice} Yes{n}{choice} No' |
| P101_EXP_DLG_TABLE | 334062–3340D5 | F3:4062–F3:40D5 | 116 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1002: 'VALE (placeholder): TECH v0.3.{n}This text is from bank F3.{n}Annex flag STARTED is now ON.{n}The north door is unsealed.' |
| P101_EXP_DLG_TABLE | 3340D6–33413D | F3:40D6–F3:413D | 104 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1003: 'VALE (placeholder):{n}Annex flag STARTED is still ON.{n}Go north through the door{n}to start the test battle.' |
| P101_EXP_DLG_TABLE | 33413E–3341A6 | F3:413E–F3:41A6 | 105 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1004: 'VALE (placeholder):{n}Annex flag BATTLE DONE is ON.{n}Take the test reward from{n}the chest in the north room.' |
| P101_EXP_DLG_TABLE | 3341A7–33420E | F3:41A7–F3:420E | 104 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1005: 'VALE (placeholder):{n}Annex flag COMPLETE is ON.{n}TECH slice finished. Exit{n}south to return to the Falcon.' |
| P101_EXP_DLG_TABLE | 33420F–334238 | F3:420F–F3:4238 | 42 | `FF fill (expansion)` | `33 41 3E 7F 3D 48 48 4B 7F 42 4C 7F 4C 3E 3A 45 3E 3D 65 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1006: 'The door is sealed.{n}(Talk to VALE first.)' |
| P101_EXP_DLG_TABLE | 334239–334271 | F3:4239–F3:4271 | 57 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 57 61 7F 20 47 47 3E 51 7F 3D 3E …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1007: 'TECH v0.3: Annex defenses{n}activate! (placeholder battle)' |
| P101_EXP_DLG_TABLE | 334272–3342A2 | F3:4272–F3:42A2 | 49 | `FF fill (expansion)` | `23 3E 3F 3E 47 4C 3E 4C 7F 3A 4B 3E 7F 3D 48 50 47 65 01 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1008: 'Defenses are down.{n}Annex flag BATTLE DONE is ON.' |
| P101_EXP_DLG_TABLE | 3342A3–3342EE | F3:42A3–F3:42EE | 76 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 57 7F 49 45 3A 3C 3E 41 48 45 3D …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1009: 'TECH v0.3 placeholder reward:{n}Received 1 Potion.{n}Annex flag COMPLETE is ON.' |
| P101_EXP_DLG_TABLE | 3342EF–33431A | F3:42EF–F3:431A | 44 | `FF fill (expansion)` | `33 41 3E 7F 3C 41 3E 4C 4D 7F 42 4C 7F 3E 46 49 4D 52 65 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100A: 'The chest is empty.{n}(Reward already taken.)' |
| P101_EXP_DLG_TABLE | 33431B–33438B | F3:431B–F3:438B | 113 | `FF fill (expansion)` | `33 24 22 27 7F 20 55 61 7F 46 3A 49 7F 55 20 54 7F 6B 47 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100B: 'TECH A1: map 1A0 (new ID).{n}NPC data: relocated table F6.{n}My event: vector table F7.{n}Visit the room to the north.' |
| P101_EXP_DLG_TABLE | 33438C–3343E1 | F3:438C–F3:43E1 | 86 | `FF fill (expansion)` | `33 24 22 27 7F 20 55 61 7F 3F 45 3A 40 7F 35 28 32 28 33 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100C: 'TECH A1: flag VISITED B is ON.{n}The new NPC (A2) appeared.{n}NPC switch on a new map OK.' |
| P101_EXP_DLG_TABLE | 3343E2–334435 | F3:43E2–F3:4435 | 84 | `FF fill (expansion)` | `33 24 22 27 7F 20 57 61 7F 4C 3E 3C 48 47 3D 7F 4B 48 4E …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100D: 'TECH A3: second routed NPC.{n}Layout 160 is read from the{n}relocated pointer table F7.' |
| P101_EXP_DLG_TABLE | 334436–334474 | F3:4436–F3:4474 | 63 | `FF fill (expansion)` | `33 24 22 27 7F 20 56 61 7F 28 7F 3A 46 7F 4F 42 4C 42 3B …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100E: 'TECH A2: I am visible only{n}after VISITED B was set{n}in map 1A1.' |
| P101_EXP_DLG_TABLE | 334475–3344AB | F3:4475–F3:44AB | 55 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 58 61 7F 3E 4F 3E 47 4D 7F 4D 4B …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100F: 'TECH v0.4: event trigger on{n}map 1A0 (relocated table).' |
| P101_EXP_DLG_TABLE | 3344AC–3344FB | F3:44AC–F3:44FB | 80 | `FF fill (expansion)` | `33 24 22 27 7F 21 55 61 7F 46 3A 49 7F 55 20 55 7F 6B 47 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1010: 'TECH B1: map 1A1 (new ID).{n}Composed vanilla room art.{n}Flag VISITED B is now ON.' |
| P101_EXP_DLG_TABLE | 3344FC–334548 | F3:44FC–F3:4548 | 77 | `FF fill (expansion)` | `33 24 22 27 7F 21 55 61 7F 35 28 32 28 33 24 23 7F 21 7F …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1011: 'TECH B1: VISITED B is still ON.{n}Door: short entrance.{n}Stairs: long entrance.' |
| P101_EXP_DLG_TABLE | 330000–330047 | F3:0000–F3:0047 | 72 | `FF fill (expansion)` | `00 40 F3 00 2B 40 F3 00 62 40 F3 00 D6 40 F3 00 3E 41 F3 …` | P100 hook (LDA.l table,X) — 18 x 4-byte pointers for dialogue IDs $1000-$1011 |
| Q502_QA_DLG | 3F0800–3F084D | FF:0800–FF:084D | 78 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 59 7F 30 20 7F 20 22 22 24 32 32 …` | field text renderer via $C9/$CB set by P100 hook — QA dialogue $1012: 'TECH v0.5 QA ACCESS{n}{choice} Monster test battle{n}{choice} Map/Annex tests{n}{choice} No (Save Point)' |
| Q502_QA_DLG | 3F084E–3F0892 | FF:084E–FF:0892 | 69 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 59 61 7F 33 24 32 33 2C 2E 21 7F …` | field text renderer via $C9/$CB set by P100 hook — QA dialogue $1013: 'TECH v0.5: TESTMOB A + B{n}New monster IDs 180 and 181.{n}Formation 240.' |
| Q502_QA_DLG | 3F0893–3F08C5 | FF:0893–FF:08C5 | 51 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 59 61 7F 3B 3A 4D 4D 45 3E 7F 4B …` | field text renderer via $C9/$CB set by P100 hook — QA dialogue $1014: 'TECH v0.5: battle returned{n}to the field correctly.' |
| Q502_QA_DLG | 3F08C6–3F0909 | FF:08C6–FF:0909 | 68 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 59 7F 30 20 61 7F 48 4D 41 3E 4B …` | field text renderer via $C9/$CB set by P100 hook — QA dialogue $1015: 'TECH v0.5 QA: other tests{n}{choice} Map test A (1A0){n}{choice} Celes Annex{n}{choice} Cancel' |
| Q502_QA_DLG | 330048–330057 | F3:0048–F3:0057 | 16 | `FF fill (expansion)` | `00 08 FF 00 4E 08 FF 00 93 08 FF 00 C6 08 FF 00` | P100 hook — pointer slots for QA IDs $1012+ |
| P100_DLG_HOOK | 301000–301032 | F0:1000–F0:1032 | 51 | `FF fill (expansion)` | `C2 20 A5 D0 C9 00 10 B0 0A E2 20 A9 CD 85 CB 5C C3 7F C0 …` | JML from C0:7FBF (GetDlgPtr) — Dialogue-pointer hook: vanilla IDs unchanged, IDs $1000+ from expansion table |
| P100_DLG_HOOK | 007FBF–007FC2 | C0:7FBF–C0:7FC2 | 4 | `A9 CD 85 CB` | `5C 00 10 F0` | GetDlgPtr C0:7FBF; callers C0:A49A ($48), C0:A4E1 ($4B), C0:D493 (debug) — Replace LDA #$CD / STA $CB with JML $F01000 (displaced code re-executed in hook) |
| T400_ANNEX_EVENTS | 310000–31007E | F1:0000–F1:007E | 127 | `FF fill (expansion)` | `4B 01 10 B6 0A 00 27 1B 00 27 DC F8 C0 4C 81 14 00 27 DC …` | event interpreter via 24-bit trigger pointers, NPC vectors, call/jump operands — celes_annex_tech event scripts (127 bytes) from events/celes_annex_tech/events.evt |
| T410_MAPTECH_EVENTS | 311000–31102F | F1:1000–F1:102F | 48 | `FF fill (expansion)` | `C0 4D 81 0A 10 27 4B 0B 10 FE 4B 0C 10 FE 4B 0D 10 FE 4B …` | event interpreter via 24-bit trigger pointers, NPC vectors, call/jump operands — map_tech_v04 event scripts (48 bytes) from events/map_tech_v04/events.evt |
| Q500_QA_EVENT | 3F0000–3F0043 | FF:0000–FF:0043 | 68 | `FF fill (expansion)` | `C0 B5 81 43 00 35 4B 12 10 B6 13 00 35 26 00 35 3F 00 35 …` | event interpreter via 24-bit trigger pointers, NPC vectors, call/jump operands — qa_access_v05 event scripts (68 bytes) from events/qa_access_v05/events.evt |
| T402_ANNEX_LAYOUT | 350000–350481 | F5:0000–F5:0481 | 1154 | `FF fill (expansion)` | `<1154 bytes, sha1 97530fee0e90617be22c2a6af2f1c6556c55766b>` | LoadMapTiles via MAPX_SUBTILEMAP_PTRS[$15F] — map 0C7 BG1 layout $15F (32x32, literal LZSS 1154 B) |
| T412_MAPTECH_LAYOUTS | 350482–350903 | F5:0482–F5:0903 | 1154 | `FF fill (expansion)` | `<1154 bytes, sha1 294f321d350ee4c73de34858dc0452bb3e23c7dd>` | LoadMapTiles via MAPX_SUBTILEMAP_PTRS[$160] — map 1A0 BG1 layout $160 (32x32, literal LZSS 1154 B) |
| T412_MAPTECH_LAYOUTS | 350904–350D85 | F5:0904–F5:0D85 | 1154 | `FF fill (expansion)` | `<1154 bytes, sha1 68aafd97746e464df50a556cf598866351f4195b>` | LoadMapTiles via MAPX_SUBTILEMAP_PTRS[$161] — map 1A1 BG1 layout $161 (32x32, literal LZSS 1154 B) |
| T412_MAPTECH_LAYOUTS | 350D86–351207 | F5:0D86–F5:1207 | 1154 | `FF fill (expansion)` | `<1154 bytes, sha1 888206026170155e16d1d5a7116f4665c728ac3f>` | LoadMapTiles via MAPX_SUBTILEMAP_PTRS[$162] — map 1A1 BG2 layout $162 (32x32, literal LZSS 1154 B) |
| M101_MAPX_EVENT_TRIGGERS | 360000–361AD1 | F6:0000–F6:1AD1 | 6866 | `FF fill (expansion)` | `<6866 bytes, sha1 0ff6be7251ca5d97d68f4f96ecefcbfff62c25b9>` | 12 retargeted consumers — EVENT_TRIGGERS: 1164 vanilla records (maps $000-$19F) + 4 content records; 513 pointers |
| M102_MAPX_NPC_PROPS | 364000–369150 | F6:4000–F6:9150 | 20817 | `FF fill (expansion)` | `<20817 bytes, sha1 d00d7fac6f3feffe0f2737b93d1855aa10914d77>` | 21 retargeted consumers — NPC_PROPS: 2193 vanilla records (maps $000-$19F) + 6 content records; 513 pointers |
| M103_MAPX_SHORT_ENTRANCES | 36C000–36DE89 | F6:C000–F6:DE89 | 7818 | `FF fill (expansion)` | `<7818 bytes, sha1 0bd3b92f5b23d7da15b1001994adc3e35416b438>` | 19 retargeted consumers — SHORT_ENTRANCES: 1129 vanilla records (maps $000-$1FF) + 3 content records; 513 pointers |
| M104_MAPX_LONG_ENTRANCES | 370000–370837 | F7:0000–F7:0837 | 2104 | `FF fill (expansion)` | `<2104 bytes, sha1 97e1ad36002b88f30dfa00fd7967e6b0c67f52f9>` | 19 retargeted consumers — LONG_ENTRANCES: 152 vanilla records (maps $000-$1FF) + 2 content records; 513 pointers |
| M105_MAPX_TREASURE | 372000–372997 | F7:2000–F7:2997 | 2456 | `FF fill (expansion)` | `<2456 bytes, sha1 da3999f9095378d1e09f048ecd0039465600bed1>` | 12 retargeted consumers — TREASURE: 286 vanilla records (maps $000-$19E) + 0 content records; 513 pointers |
| M106_MAPX_MAP_PROPS | 374000–3781FF | F7:4000–F7:81FF | 16896 | `FF fill (expansion)` | `<16896 bytes, sha1 67269e2dd3846ca7295d0009536ab5d1af4d8850>` | LoadMapProp C0:1CAD (LDA.l MapProp,X; X = map*33) — 512 x 33-byte rows: vanilla $000-$19E copied; content rows ['0C7', '1A0', '1A1'] |
| M107_MAPX_SUBTILEMAP_PTRS | 378400–378FFF | F7:8400–F7:8FFF | 3072 | `FF fill (expansion)` | `<3072 bytes, sha1 6997bf4488929d464fd6d72dd5804b0502b11ae0>` | LoadMapTiles C0:2883 (BG1/BG2/BG3, 10-bit index * 3) — 1024 layout pointers: vanilla $000-$15E copied, unassigned = entry $000 value; content ['15F', '160', '161', '162'] |
| M108_NPC_EVENT_VECTORS | 379000–379011 | F7:9000–F7:9011 | 18 | `FF fill (expansion)` | `1C 00 F1 69 00 F1 00 10 F1 0E 10 F1 12 10 F1 1E 10 F1` | M300 router (LDA.l vectors,X) — NPC event vectors: #0=F1:001C (0C7:VALE_PLACEHOLDER->EvVale), #1=F1:0069 (0C7:REWARD_CHEST->EvChest), #2=F1:1000 (1A0:TECH_A1->EvA1), #3=F1:100E (1A0:TECH_A3->EvA3), #4=F1:1012 (1A0:TECH_A2->EvA2), #5=F1:101E (1A1:TECH_B1->EvB1) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCAF–00BCB1 | C0:BCAF–C0:BCB1 | 3 | `02 00 C4` | `02 00 F6` | C0:BCAE opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCB5–00BCB7 | C0:BCB5–C0:BCB7 | 3 | `00 00 C4` | `00 00 F6` | C0:BCB4 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCBE–00BCC0 | C0:BCBE–C0:BCC0 | 3 | `00 00 C4` | `00 00 F6` | C0:BCBD opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCD4–00BCD6 | C0:BCD4–C0:BCD6 | 3 | `02 00 C4` | `02 00 F6` | C0:BCD3 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCEE–00BCF0 | C0:BCEE–C0:BCF0 | 3 | `04 00 C4` | `04 00 F6` | C0:BCED opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0004 -> F6:0004 (ptr base + 4) |
| M200_RETARGET_EVENT_TRIGGERS | 2E2177–2E2179 | EE:2177–EE:2179 | 3 | `00 00 C4` | `00 00 F6` | EE:2176 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 2E217D–2E217F | EE:217D–EE:217F | 3 | `02 00 C4` | `02 00 F6` | EE:217C opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 2E218C–2E218E | EE:218C–EE:218E | 3 | `00 00 C4` | `00 00 F6` | EE:218B opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 2E2194–2E2196 | EE:2194–EE:2196 | 3 | `01 00 C4` | `01 00 F6` | EE:2193 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0001 -> F6:0001 (ptr base + 1) |
| M200_RETARGET_EVENT_TRIGGERS | 2E219C–2E219E | EE:219C–EE:219E | 3 | `02 00 C4` | `02 00 F6` | EE:219B opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 2E21A5–2E21A7 | EE:21A5–EE:21A7 | 3 | `03 00 C4` | `03 00 F6` | EE:21A4 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0003 -> F6:0003 (ptr base + 3) |
| M200_RETARGET_EVENT_TRIGGERS | 2E21AD–2E21AF | EE:21AD–EE:21AF | 3 | `04 00 C4` | `04 00 F6` | EE:21AC opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0004 -> F6:0004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 0052BD–0052BF | C0:52BD–C0:52BF | 3 | `12 1A C4` | `02 40 F6` | C0:52BC opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052C3–0052C5 | C0:52C3–C0:52C5 | 3 | `10 1A C4` | `00 40 F6` | C0:52C2 opcode BF (long,X) reads NPC_PROPS — operand C4:1A10 -> F6:4000 (ptr base + 0) |
| M200_RETARGET_NPC_PROPS | 0052D5–0052D7 | C0:52D5–C0:52D7 | 3 | `10 1A C4` | `00 40 F6` | C0:52D4 opcode BF (long,X) reads NPC_PROPS — operand C4:1A10 -> F6:4000 (ptr base + 0) |
| M200_RETARGET_NPC_PROPS | 0052DC–0052DE | C0:52DC–C0:52DE | 3 | `11 1A C4` | `01 40 F6` | C0:52DB opcode BF (long,X) reads NPC_PROPS — operand C4:1A11 -> F6:4001 (ptr base + 1) |
| M200_RETARGET_NPC_PROPS | 0052E3–0052E5 | C0:52E3–C0:52E5 | 3 | `12 1A C4` | `02 40 F6` | C0:52E2 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052EC–0052EE | C0:52EC–C0:52EE | 3 | `12 1A C4` | `02 40 F6` | C0:52EB opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052F9–0052FB | C0:52F9–C0:52FB | 3 | `12 1A C4` | `02 40 F6` | C0:52F8 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 005306–005308 | C0:5306–C0:5308 | 3 | `12 1A C4` | `02 40 F6` | C0:5305 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 005322–005324 | C0:5322–C0:5324 | 3 | `14 1A C4` | `04 40 F6` | C0:5321 opcode BF (long,X) reads NPC_PROPS — operand C4:1A14 -> F6:4004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 00532D–00532F | C0:532D–C0:532F | 3 | `14 1A C4` | `04 40 F6` | C0:532C opcode BF (long,X) reads NPC_PROPS — operand C4:1A14 -> F6:4004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 00533B–00533D | C0:533B–C0:533D | 3 | `15 1A C4` | `05 40 F6` | C0:533A opcode BF (long,X) reads NPC_PROPS — operand C4:1A15 -> F6:4005 (ptr base + 5) |
| M200_RETARGET_NPC_PROPS | 00535B–00535D | C0:535B–C0:535D | 3 | `15 1A C4` | `05 40 F6` | C0:535A opcode BF (long,X) reads NPC_PROPS — operand C4:1A15 -> F6:4005 (ptr base + 5) |
| M200_RETARGET_NPC_PROPS | 00536A–00536C | C0:536A–C0:536C | 3 | `16 1A C4` | `06 40 F6` | C0:5369 opcode BF (long,X) reads NPC_PROPS — operand C4:1A16 -> F6:4006 (ptr base + 6) |
| M200_RETARGET_NPC_PROPS | 005374–005376 | C0:5374–C0:5376 | 3 | `17 1A C4` | `07 40 F6` | C0:5373 opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 005380–005382 | C0:5380–C0:5382 | 3 | `17 1A C4` | `07 40 F6` | C0:537F opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 00538B–00538D | C0:538B–C0:538D | 3 | `17 1A C4` | `07 40 F6` | C0:538A opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 005398–00539A | C0:5398–C0:539A | 3 | `18 1A C4` | `08 40 F6` | C0:5397 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053AE–0053B0 | C0:53AE–C0:53B0 | 3 | `18 1A C4` | `08 40 F6` | C0:53AD opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053BD–0053BF | C0:53BD–C0:53BF | 3 | `18 1A C4` | `08 40 F6` | C0:53BC opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053D1–0053D3 | C0:53D1–C0:53D3 | 3 | `18 1A C4` | `08 40 F6` | C0:53D0 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053E4–0053E6 | C0:53E4–C0:53E6 | 3 | `18 1A C4` | `08 40 F6` | C0:53E3 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_SHORT_ENTRANCES | 001A7E–001A80 | C0:1A7E–C0:1A80 | 3 | `02 BB DF` | `02 C0 F6` | C0:1A7D opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001A84–001A86 | C0:1A84–C0:1A86 | 3 | `00 BB DF` | `00 C0 F6` | C0:1A83 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 001A90–001A92 | C0:1A90–C0:1A92 | 3 | `00 BB DF` | `00 C0 F6` | C0:1A8F opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 001AAB–001AAD | C0:1AAB–C0:1AAD | 3 | `02 BB DF` | `02 C0 F6` | C0:1AAA opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AB7–001AB9 | C0:1AB7–C0:1AB9 | 3 | `02 BB DF` | `02 C0 F6` | C0:1AB6 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AC3–001AC5 | C0:1AC3–C0:1AC5 | 3 | `02 BB DF` | `02 C0 F6` | C0:1AC2 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AD2–001AD4 | C0:1AD2–C0:1AD4 | 3 | `04 BB DF` | `04 C0 F6` | C0:1AD1 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_SHORT_ENTRANCES | 001AE7–001AE9 | C0:1AE7–C0:1AE9 | 3 | `04 BB DF` | `04 C0 F6` | C0:1AE6 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_SHORT_ENTRANCES | 001AF1–001AF3 | C0:1AF1–C0:1AF3 | 3 | `03 BB DF` | `03 C0 F6` | C0:1AF0 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001AFE–001B00 | C0:1AFE–C0:1B00 | 3 | `03 BB DF` | `03 C0 F6` | C0:1AFD opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001B0C–001B0E | C0:1B0C–C0:1B0E | 3 | `03 BB DF` | `03 C0 F6` | C0:1B0B opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001B2D–001B2F | C0:1B2D–C0:1B2F | 3 | `02 BB DF` | `02 C0 F6` | C0:1B2C opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001B5F–001B61 | C0:1B5F–C0:1B61 | 3 | `03 BB DF` | `03 C0 F6` | C0:1B5E opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20EA–2E20EC | EE:20EA–EE:20EC | 3 | `00 BB DF` | `00 C0 F6` | EE:20E9 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20F0–2E20F2 | EE:20F0–EE:20F2 | 3 | `02 BB DF` | `02 C0 F6` | EE:20EF opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20FF–2E2101 | EE:20FF–EE:2101 | 3 | `00 BB DF` | `00 C0 F6` | EE:20FE opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 2E2107–2E2109 | EE:2107–EE:2109 | 3 | `01 BB DF` | `01 C0 F6` | EE:2106 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB01 -> F6:C001 (ptr base + 1) |
| M200_RETARGET_SHORT_ENTRANCES | 2E2111–2E2113 | EE:2111–EE:2113 | 3 | `02 BB DF` | `02 C0 F6` | EE:2110 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 2E213D–2E213F | EE:213D–EE:213F | 3 | `04 BB DF` | `04 C0 F6` | EE:213C opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0018EB–0018ED | C0:18EB–C0:18ED | 3 | `82 F4 ED` | `02 00 F7` | C0:18EA opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F482 -> F7:0002 (ptr base + 2) |
| M200_RETARGET_LONG_ENTRANCES | 0018F1–0018F3 | C0:18F1–C0:18F3 | 3 | `80 F4 ED` | `00 00 F7` | C0:18F0 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 001904–001906 | C0:1904–C0:1906 | 3 | `82 F4 ED` | `02 00 F7` | C0:1903 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F482 -> F7:0002 (ptr base + 2) |
| M200_RETARGET_LONG_ENTRANCES | 00190C–00190E | C0:190C–C0:190E | 3 | `81 F4 ED` | `01 00 F7` | C0:190B opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001917–001919 | C0:1917–C0:1919 | 3 | `80 F4 ED` | `00 00 F7` | C0:1916 opcode FF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 00191F–001921 | C0:191F–C0:1921 | 3 | `80 F4 ED` | `00 00 F7` | C0:191E opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 001930–001932 | C0:1930–C0:1932 | 3 | `80 F4 ED` | `00 00 F7` | C0:192F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 00193B–00193D | C0:193B–C0:193D | 3 | `81 F4 ED` | `01 00 F7` | C0:193A opcode FF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001943–001945 | C0:1943–C0:1945 | 3 | `81 F4 ED` | `01 00 F7` | C0:1942 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001964–001966 | C0:1964–C0:1966 | 3 | `83 F4 ED` | `03 00 F7` | C0:1963 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 001970–001972 | C0:1970–C0:1972 | 3 | `83 F4 ED` | `03 00 F7` | C0:196F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 00197C–00197E | C0:197C–C0:197E | 3 | `83 F4 ED` | `03 00 F7` | C0:197B opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 00198B–00198D | C0:198B–C0:198D | 3 | `85 F4 ED` | `05 00 F7` | C0:198A opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F485 -> F7:0005 (ptr base + 5) |
| M200_RETARGET_LONG_ENTRANCES | 0019A0–0019A2 | C0:19A0–C0:19A2 | 3 | `85 F4 ED` | `05 00 F7` | C0:199F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F485 -> F7:0005 (ptr base + 5) |
| M200_RETARGET_LONG_ENTRANCES | 0019AA–0019AC | C0:19AA–C0:19AC | 3 | `84 F4 ED` | `04 00 F7` | C0:19A9 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019B7–0019B9 | C0:19B7–C0:19B9 | 3 | `84 F4 ED` | `04 00 F7` | C0:19B6 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019C5–0019C7 | C0:19C5–C0:19C7 | 3 | `84 F4 ED` | `04 00 F7` | C0:19C4 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019E6–0019E8 | C0:19E6–C0:19E8 | 3 | `83 F4 ED` | `03 00 F7` | C0:19E5 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 001A15–001A17 | C0:1A15–C0:1A17 | 3 | `84 F4 ED` | `04 00 F7` | C0:1A14 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_TREASURE | 0015DE–0015E0 | C0:15DE–C0:15E0 | 3 | `F6 82 ED` | `02 20 F7` | C0:15DD opcode BF (long,X) reads TREASURE — operand ED:82F6 -> F7:2002 (ptr base + 2) |
| M200_RETARGET_TREASURE | 0015E4–0015E6 | C0:15E4–C0:15E6 | 3 | `F4 82 ED` | `00 20 F7` | C0:15E3 opcode BF (long,X) reads TREASURE — operand ED:82F4 -> F7:2000 (ptr base + 0) |
| M200_RETARGET_TREASURE | 0015F2–0015F4 | C0:15F2–C0:15F4 | 3 | `34 86 ED` | `02 24 F7` | C0:15F1 opcode BF (long,X) reads TREASURE — operand ED:8634 -> F7:2402 (data base + 0) |
| M200_RETARGET_TREASURE | 0015F8–0015FA | C0:15F8–C0:15FA | 3 | `35 86 ED` | `03 24 F7` | C0:15F7 opcode BF (long,X) reads TREASURE — operand ED:8635 -> F7:2403 (data base + 1) |
| M200_RETARGET_TREASURE | 0015FF–001601 | C0:15FF–C0:1601 | 3 | `36 86 ED` | `04 24 F7` | C0:15FE opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_TREASURE | 00160A–00160C | C0:160A–C0:160C | 3 | `36 86 ED` | `04 24 F7` | C0:1609 opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_TREASURE | 004BDB–004BDD | C0:4BDB–C0:4BDD | 3 | `F6 82 ED` | `02 20 F7` | C0:4BDA opcode BF (long,X) reads TREASURE — operand ED:82F6 -> F7:2002 (ptr base + 2) |
| M200_RETARGET_TREASURE | 004BE1–004BE3 | C0:4BE1–C0:4BE3 | 3 | `F4 82 ED` | `00 20 F7` | C0:4BE0 opcode BF (long,X) reads TREASURE — operand ED:82F4 -> F7:2000 (ptr base + 0) |
| M200_RETARGET_TREASURE | 004BED–004BEF | C0:4BED–C0:4BEF | 3 | `34 86 ED` | `02 24 F7` | C0:4BEC opcode BF (long,X) reads TREASURE — operand ED:8634 -> F7:2402 (data base + 0) |
| M200_RETARGET_TREASURE | 004BF5–004BF7 | C0:4BF5–C0:4BF7 | 3 | `35 86 ED` | `03 24 F7` | C0:4BF4 opcode BF (long,X) reads TREASURE — operand ED:8635 -> F7:2403 (data base + 1) |
| M200_RETARGET_TREASURE | 004C09–004C0B | C0:4C09–C0:4C0B | 3 | `38 86 ED` | `06 24 F7` | C0:4C08 opcode BF (long,X) reads TREASURE — operand ED:8638 -> F7:2406 (data base + 4) |
| M200_RETARGET_TREASURE | 004C0F–004C11 | C0:4C0F–C0:4C11 | 3 | `36 86 ED` | `04 24 F7` | C0:4C0E opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_MAP_PROPS | 001CC0–001CC2 | C0:1CC0–C0:1CC2 | 3 | `00 8F ED` | `00 40 F7` | C0:1CBF opcode BF (long,X) reads MAP_PROPS — operand ED:8F00 -> F7:4000 (data base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 002893–002895 | C0:2893–C0:2895 | 3 | `90 CD D9` | `00 84 F7` | C0:2892 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028A0–0028A2 | C0:28A0–C0:28A2 | 3 | `92 CD D9` | `02 84 F7` | C0:289F opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028E7–0028E9 | C0:28E7–C0:28E9 | 3 | `90 CD D9` | `00 84 F7` | C0:28E6 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028F4–0028F6 | C0:28F4–C0:28F6 | 3 | `92 CD D9` | `02 84 F7` | C0:28F3 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M200_RETARGET_SUBTILEMAP_PTRS | 00293D–00293F | C0:293D–C0:293F | 3 | `90 CD D9` | `00 84 F7` | C0:293C opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 00294A–00294C | C0:294A–C0:294C | 3 | `92 CD D9` | `02 84 F7` | C0:2949 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M300_NPC_EVENT_ROUTER | 301100–301146 | F0:1100–F0:1146 | 71 | `FF fill (expansion)` | `29 03 C9 03 D0 3D BF 04 40 F6 30 35 C2 20 B9 89 08 C9 06 …` | JSL from C0:52E6 (InitNPCs) — NPC event router: vanilla NPCs unchanged; non-special NPCs with event field $3xxxx -> vector table |
| M300_NPC_EVENT_ROUTER | 0052E6–0052EA | C0:52E6–C0:52EA | 5 | `29 03 99 8B 08` | `22 00 11 F0 EA` | InitNPCs C0:52E6 (after LDA NPCProp::EventPtr+2,X) — AND #$03 / STA $088B,Y -> JSL F0:1100 / NOP (router re-executes both for vanilla NPCs) |
| Q503_QA_ANNEX_BATTLE_GROUP | 310057–310059 | F1:0057–F1:0059 | 3 | `4D 28 3F` | `4D 01 3F` | event cmd $4D in EvBattleDoor_Fight — QA: Annex battle group $28 -> $01 (as v0.3.1/v0.4 harness) |
| N101_MONSTER_PROP | 380000–383FFF | F8:0000–F8:3FFF | 16384 | `FF fill (expansion)` | `<16384 bytes, sha1 78ed2b9e73a96b4e98301cfbb79d81d1f986f642>` | 25 retargeted consumers — MONSTER_PROP relocated (16384 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N102_MONSTER_NAME | 384000–3853FF | F8:4000–F8:53FF | 5120 | `FF fill (expansion)` | `<5120 bytes, sha1 03f67fce6671d8c130538d1e51172e6418371a74>` | 6 retargeted consumers — MONSTER_NAME relocated (5120 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N103_MONSTER_SPECIAL_NAME | 385400–3867FF | F8:5400–F8:67FF | 5120 | `FF fill (expansion)` | `<5120 bytes, sha1 14ce0d290b1c939abe6364ba6df1ae2f4e65f9a9>` | 2 retargeted consumers — MONSTER_SPECIAL_NAME relocated (5120 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N104_MONSTER_ITEMS | 386800–386FFF | F8:6800–F8:6FFF | 2048 | `FF fill (expansion)` | `<2048 bytes, sha1 93ca23eed6e44966d5c659b2070b7634fd9d2c34>` | 2 retargeted consumers — MONSTER_ITEMS relocated (2048 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N105_MONSTER_CONTROL | 387000–3877FF | F8:7000–F8:77FF | 2048 | `FF fill (expansion)` | `<2048 bytes, sha1 358dca711cf970c7a22fd4c9456e15ce68bbaaf1>` | 3 retargeted consumers — MONSTER_CONTROL relocated (2048 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N106_MONSTER_SKETCH | 387800–387BFF | F8:7800–F8:7BFF | 1024 | `FF fill (expansion)` | `<1024 bytes, sha1 c8d826ccfbd31cd3c561717c192d84e5d36452e0>` | 1 retargeted consumers — MONSTER_SKETCH relocated (1024 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N107_MONSTER_SPECIAL_ANIM | 387C00–387DFF | F8:7C00–F8:7DFF | 512 | `FF fill (expansion)` | `03 03 0D 18 07 0E 1B 21 0C 10 0B 0C 0C 00 1C 0E 12 0B 15 …` | 2 retargeted consumers — MONSTER_SPECIAL_ANIM relocated (512 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N108_MONSTER_OVERLAP | 387E00–387FFF | F8:7E00–F8:7FFF | 512 | `FF fill (expansion)` | `00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 …` | 1 retargeted consumers — MONSTER_OVERLAP relocated (512 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N109_MONSTER_GFX_PROP | 388000–388A9A | F8:8000–F8:8A9A | 2715 | `FF fill (expansion)` | `<2715 bytes, sha1 27bfdff0170f7e6ff2a0e7c755f091b3bdaee3d4>` | 15 retargeted consumers — MONSTER_GFX_PROP relocated (2715 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N112_AI_SCRIPT_PTRS | 390000–3903FF | F9:0000–F9:03FF | 1024 | `FF fill (expansion)` | `<1024 bytes, sha1 05aa7e9502b167036c0a0e7c035a3dcac8f6fd61>` | 1 retargeted consumers — AI_SCRIPT_PTRS relocated (1024 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N113_AI_SCRIPT | 390400–393D5D | F9:0400–F9:3D5D | 14686 | `FF fill (expansion)` | `<14686 bytes, sha1 b8e5800cf1b7edb942f0d3f828054294873d1304>` | 4 retargeted consumers — AI_SCRIPT relocated (14686 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N110_FORMATION_PROP | 389000–389FFF | F8:9000–F8:9FFF | 4096 | `FF fill (expansion)` | `<4096 bytes, sha1 216719125625d15ede53bdfa03f6fb777ba4a497>` | 2 retargeted consumers — FORMATION_PROP relocated (4096 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N111_FORMATION_MONSTERS | 38A000–38DC0F | F8:A000–F8:DC0F | 15376 | `FF fill (expansion)` | `<15376 bytes, sha1 530f3bfe27c9a01e54368917ab01a7b28e1017ff>` | 7 retargeted consumers — FORMATION_MONSTERS relocated (15376 bytes); vanilla entries byte-identical; content: ['180', '181'] |
| N200_RETARGET_MONSTER_PROP | 020626–020628 | C2:0626–C2:0628 | 3 | `1A 00 CF` | `1A 00 F8` | C2:0625 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 26 |
| N200_RETARGET_MONSTER_PROP | 022CA4–022CA6 | C2:2CA4–C2:2CA6 | 3 | `05 00 CF` | `05 00 F8` | C2:2CA3 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 5 |
| N200_RETARGET_MONSTER_PROP | 022CAB–022CAD | C2:2CAB–C2:2CAD | 3 | `0C 00 CF` | `0C 00 F8` | C2:2CAA opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 12 |
| N200_RETARGET_MONSTER_PROP | 022CB2–022CB4 | C2:2CB2–C2:2CB4 | 3 | `0E 00 CF` | `0E 00 F8` | C2:2CB1 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 14 |
| N200_RETARGET_MONSTER_PROP | 022CBE–022CC0 | C2:2CBE–C2:2CC0 | 3 | `0A 00 CF` | `0A 00 F8` | C2:2CBD opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 10 |
| N200_RETARGET_MONSTER_PROP | 022CC8–022CCA | C2:2CC8–C2:2CCA | 3 | `08 00 CF` | `08 00 F8` | C2:2CC7 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 8 |
| N200_RETARGET_MONSTER_PROP | 022CF6–022CF8 | C2:2CF6–C2:2CF8 | 3 | `01 00 CF` | `01 00 F8` | C2:2CF5 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 1 |
| N200_RETARGET_MONSTER_PROP | 022CFD–022CFF | C2:2CFD–C2:2CFF | 3 | `1A 00 CF` | `1A 00 F8` | C2:2CFC opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 26 |
| N200_RETARGET_MONSTER_PROP | 022D04–022D06 | C2:2D04–C2:2D06 | 3 | `03 00 CF` | `03 00 F8` | C2:2D03 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 3 |
| N200_RETARGET_MONSTER_PROP | 022D0E–022D10 | C2:2D0E–C2:2D10 | 3 | `04 00 CF` | `04 00 F8` | C2:2D0D opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 4 |
| N200_RETARGET_MONSTER_PROP | 022D18–022D1A | C2:2D18–C2:2D1A | 3 | `02 00 CF` | `02 00 F8` | C2:2D17 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 2 |
| N200_RETARGET_MONSTER_PROP | 022D1F–022D21 | C2:2D1F–C2:2D21 | 3 | `10 00 CF` | `10 00 F8` | C2:2D1E opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 16 |
| N200_RETARGET_MONSTER_PROP | 022D26–022D28 | C2:2D26–C2:2D28 | 3 | `00 00 CF` | `00 00 F8` | C2:2D25 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 0 |
| N200_RETARGET_MONSTER_PROP | 022D2D–022D2F | C2:2D2D–C2:2D2F | 3 | `07 00 CF` | `07 00 F8` | C2:2D2C opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 7 |
| N200_RETARGET_MONSTER_PROP | 022D37–022D39 | C2:2D37–C2:2D39 | 3 | `1E 00 CF` | `1E 00 F8` | C2:2D36 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 30 |
| N200_RETARGET_MONSTER_PROP | 022D43–022D45 | C2:2D43–C2:2D45 | 3 | `13 00 CF` | `13 00 F8` | C2:2D42 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 19 |
| N200_RETARGET_MONSTER_PROP | 022DC3–022DC5 | C2:2DC3–C2:2DC5 | 3 | `1F 00 CF` | `1F 00 F8` | C2:2DC2 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 31 |
| N200_RETARGET_MONSTER_PROP | 022DCA–022DCC | C2:2DCA–C2:2DCC | 3 | `19 00 CF` | `19 00 F8` | C2:2DC9 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 25 |
| N200_RETARGET_MONSTER_PROP | 022DD4–022DD6 | C2:2DD4–C2:2DD6 | 3 | `16 00 CF` | `16 00 F8` | C2:2DD3 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 22 |
| N200_RETARGET_MONSTER_PROP | 022DEA–022DEC | C2:2DEA–C2:2DEC | 3 | `1B 00 CF` | `1B 00 F8` | C2:2DE9 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 27 |
| N200_RETARGET_MONSTER_PROP | 022DF1–022DF3 | C2:2DF1–C2:2DF3 | 3 | `1D 00 CF` | `1D 00 F8` | C2:2DF0 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 29 |
| N200_RETARGET_MONSTER_PROP | 022E11–022E13 | C2:2E11–C2:2E13 | 3 | `1C 00 CF` | `1C 00 F8` | C2:2E10 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 28 |
| N200_RETARGET_MONSTER_PROP | 022E1B–022E1D | C2:2E1B–C2:2E1D | 3 | `14 00 CF` | `14 00 F8` | C2:2E1A opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 20 |
| N200_RETARGET_MONSTER_PROP | 022E28–022E2A | C2:2E28–C2:2E2A | 3 | `17 00 CF` | `17 00 F8` | C2:2E27 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 23 |
| N200_RETARGET_MONSTER_PROP | 022E32–022E34 | C2:2E32–C2:2E34 | 3 | `11 00 CF` | `11 00 F8` | C2:2E31 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 17 |
| N200_RETARGET_MONSTER_NAME | 016641–016643 | C1:6641–C1:6643 | 3 | `50 C0 CF` | `00 40 F8` | C1:6640 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 0169C7–0169C9 | C1:69C7–C1:69C9 | 3 | `50 C0 CF` | `00 40 F8` | C1:69C6 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 022C57–022C59 | C2:2C57–C2:2C59 | 3 | `50 C0 CF` | `00 40 F8` | C2:2C56 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 022C79–022C7B | C2:2C79–C2:2C7B | 3 | `50 C0 CF` | `00 40 F8` | C2:2C78 opcode DF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 03540F–035410 | C3:540F–C3:5410 | 2 | `50 C0` | `00 40` | C3:540E opcode A0 (imm_near) reads MONSTER_NAME — imm_near operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 035414–035414 | C3:5414–C3:5414 | 1 | `CF` | `F8` | C3:5413 opcode A9 (imm_bank) reads MONSTER_NAME — imm_bank operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_NAME | 019739–019739 | C1:9739–C1:9739 | 1 | `CF` | `F8` | C1:9738 opcode A9 (imm_bank) reads MONSTER_SPECIAL_NAME — imm_bank operand -> F8:5400 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_NAME | 01974D–01974E | C1:974D–C1:974E | 2 | `D0 D0` | `00 54` | C1:974C opcode 69 (imm_near) reads MONSTER_SPECIAL_NAME — imm_near operand -> F8:5400 + 0 |
| N200_RETARGET_MONSTER_ITEMS | 022C42–022C44 | C2:2C42–C2:2C44 | 3 | `00 30 CF` | `00 68 F8` | C2:2C41 opcode BF (long) reads MONSTER_ITEMS — long operand -> F8:6800 + 0 |
| N200_RETARGET_MONSTER_ITEMS | 025F2E–025F30 | C2:5F2E–C2:5F30 | 3 | `02 30 CF` | `02 68 F8` | C2:5F2D opcode BF (long) reads MONSTER_ITEMS — long operand -> F8:6800 + 2 |
| N200_RETARGET_MONSTER_CONTROL | 02063E–020640 | C2:063E–C2:0640 | 3 | `00 3D CF` | `00 70 F8` | C2:063D opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 0 |
| N200_RETARGET_MONSTER_CONTROL | 020644–020646 | C2:0644–C2:0646 | 3 | `02 3D CF` | `02 70 F8` | C2:0643 opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 2 |
| N200_RETARGET_MONSTER_CONTROL | 023759–02375B | C2:3759–C2:375B | 3 | `00 3D CF` | `00 70 F8` | C2:3758 opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 0 |
| N200_RETARGET_MONSTER_SKETCH | 023B5B–023B5D | C2:3B5B–C2:3B5D | 3 | `00 43 CF` | `00 78 F8` | C2:3B5A opcode BF (long) reads MONSTER_SKETCH — long operand -> F8:7800 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_ANIM | 020617–020619 | C2:0617–C2:0619 | 3 | `C0 37 CF` | `00 7C F8` | C2:0616 opcode BF (long) reads MONSTER_SPECIAL_ANIM — long operand -> F8:7C00 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_ANIM | 022D50–022D52 | C2:2D50–C2:2D52 | 3 | `C0 37 CF` | `00 7C F8` | C2:2D4F opcode BF (long) reads MONSTER_SPECIAL_ANIM — long operand -> F8:7C00 + 0 |
| N200_RETARGET_MONSTER_OVERLAP | 012145–012147 | C1:2145–C1:2147 | 3 | `00 36 CF` | `00 7E F8` | C1:2144 opcode BF (long) reads MONSTER_OVERLAP — long operand -> F8:7E00 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 012063–012065 | C1:2063–C1:2065 | 3 | `02 70 D2` | `02 80 F8` | C1:2062 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 012081–012083 | C1:2081–C1:2083 | 3 | `00 70 D2` | `00 80 F8` | C1:2080 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 01208E–012090 | C1:208E–C1:2090 | 3 | `01 70 D2` | `01 80 F8` | C1:208D opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 012097–012099 | C1:2097–C1:2099 | 3 | `02 70 D2` | `02 80 F8` | C1:2096 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 0120AC–0120AE | C1:20AC–C1:20AE | 3 | `04 70 D2` | `04 80 F8` | C1:20AB opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_MONSTER_GFX_PROP | 0124FD–0124FF | C1:24FD–C1:24FF | 3 | `02 70 D2` | `02 80 F8` | C1:24FC opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 01250C–01250E | C1:250C–C1:250E | 3 | `00 70 D2` | `00 80 F8` | C1:250B opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 012519–01251B | C1:2519–C1:251B | 3 | `01 70 D2` | `01 80 F8` | C1:2518 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 012522–012524 | C1:2522–C1:2524 | 3 | `02 70 D2` | `02 80 F8` | C1:2521 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 012537–012539 | C1:2537–C1:2539 | 3 | `04 70 D2` | `04 80 F8` | C1:2536 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF60–03AF62 | C3:AF60–C3:AF62 | 3 | `00 70 D2` | `00 80 F8` | C3:AF5F opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF66–03AF68 | C3:AF66–C3:AF68 | 3 | `01 70 D2` | `01 80 F8` | C3:AF65 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF6C–03AF6E | C3:AF6C–C3:AF6E | 3 | `02 70 D2` | `02 80 F8` | C3:AF6B opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF72–03AF74 | C3:AF72–C3:AF74 | 3 | `03 70 D2` | `03 80 F8` | C3:AF71 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 3 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF78–03AF7A | C3:AF78–C3:AF7A | 3 | `04 70 D2` | `04 80 F8` | C3:AF77 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_AI_SCRIPT_PTRS | 022D79–022D7B | C2:2D79–C2:2D7B | 3 | `00 84 CF` | `00 00 F9` | C2:2D78 opcode BF (long) reads AI_SCRIPT_PTRS — long operand -> F9:0000 + 0 |
| N200_RETARGET_AI_SCRIPT | 021A45–021A47 | C2:1A45–C2:1A47 | 3 | `00 87 CF` | `00 04 F9` | C2:1A44 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_AI_SCRIPT | 021A65–021A67 | C2:1A65–C2:1A67 | 3 | `02 87 CF` | `02 04 F9` | C2:1A64 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 2 |
| N200_RETARGET_AI_SCRIPT | 021A6C–021A6E | C2:1A6C–C2:1A6E | 3 | `00 87 CF` | `00 04 F9` | C2:1A6B opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_AI_SCRIPT | 022D89–022D8B | C2:2D89–C2:2D8B | 3 | `00 87 CF` | `00 04 F9` | C2:2D88 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_FORMATION_PROP | 023137–023139 | C2:3137–C2:3139 | 3 | `02 59 CF` | `02 90 F8` | C2:3136 opcode BF (long) reads FORMATION_PROP — long operand -> F8:9000 + 2 |
| N200_RETARGET_FORMATION_PROP | 02313E–023140 | C2:313E–C2:3140 | 3 | `00 59 CF` | `00 90 F8` | C2:313D opcode BF (long) reads FORMATION_PROP — long operand -> F8:9000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010E9A–010E9C | C1:0E9A–C1:0E9C | 3 | `0E 62 CF` | `0E A0 F8` | C1:0E99 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 14 |
| N200_RETARGET_FORMATION_MONSTERS | 010EA2–010EA4 | C1:0EA2–C1:0EA4 | 3 | `00 62 CF` | `00 A0 F8` | C1:0EA1 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010EB5–010EB7 | C1:0EB5–C1:0EB7 | 3 | `00 62 CF` | `00 A0 F8` | C1:0EB4 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010EC0–010EC2 | C1:0EC0–C1:0EC2 | 3 | `01 62 CF` | `01 A0 F8` | C1:0EBF opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 1 |
| N200_RETARGET_FORMATION_MONSTERS | 010ED2–010ED4 | C1:0ED2–C1:0ED4 | 3 | `08 62 CF` | `08 A0 F8` | C1:0ED1 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 8 |
| N200_RETARGET_FORMATION_MONSTERS | 010EE0–010EE2 | C1:0EE0–C1:0EE2 | 3 | `08 62 CF` | `08 A0 F8` | C1:0EDF opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 8 |
| N200_RETARGET_FORMATION_MONSTERS | 023156–023158 | C2:3156–C2:3158 | 3 | `00 62 CF` | `00 A0 F8` | C2:3155 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N300_GFX_SLOT_ROUTERS | 301200–301230 | F0:1200–F0:1230 | 49 | `FF fill (expansion)` | `BD 01 20 C9 80 01 90 03 69 1F 00 48 0A 0A 18 63 01 FA 6B …` | JSL from C1:2058 (battle monster loader), C2:F5F1 (Sketch), C2:2F75 (colosseum detection) — graphics-property slot remap (monsters $180-$1FE -> slots $1A0-$21E) + colosseum range check |
| N301_GFX_SLOT_HOOK_BATTLE | 012058–012060 | C1:2058–C1:2060 | 9 | `BD 01 20 0A 0A 18 7D 01 20` | `22 00 12 F0 EA EA EA EA EA` | LoadMonsterGfxProp (C1:204E) monster id*5 computation — LDA $2001,X/ASL/ASL/CLC/ADC $2001,X -> JSL MonsterGfxSlot5 + 5x NOP |
| N302_GFX_SLOT_HOOK_SKETCH | 02F5F1–02F5F4 | C2:F5F1–C2:F5F4 | 4 | `BD 01 20 AA` | `22 13 12 F0` | battle animation init $0B (Sketch): monster id -> LoadSketchMonsterGfx — LDA $2001,X/TAX -> JSL MonsterGfxSlotSketch |
| N303_FORMATION_COLOSSEUM_RANGE | 022F75–022F7A | C2:2F75–C2:2F7A | 6 | `AE D4 3E E0 3E 02` | `22 20 12 F0 EA EA` | InitParty C2:2F75 colosseum detection (battle id >= $23E) — LDX wBattleID/CPX #$023E -> JSL ColosseumRangeCheck + 2x NOP; colosseum iff $23E <= id < $240 so new formations $240-$3FF load normally |
| Q501_QA_EVENT_BATTLE_GROUP | 0F53F8–0F53FB | CF:53F8–CF:53FB | 4 | `00 00 00 00` | `40 02 40 02` | event cmd $4D (EventBattle C0:A5A7) group $FE — QA: group $FE -> formation $240 (TESTMOB A + B) |
| P999_CHECKSUM | 00FFDC–00FFDF | C0:FFDC–C0:FFDF | 4 | `9F 75 60 8A` | `BB 53 44 AC` | SNES header (emulator/flash-cart validation) — Recalculated checksum AC44 / complement 53BB |

## celes-tech — `FF6X_Rev1_TECH_v0.5.0_CELES_TECH.sfc`

SHA-1 `3805944217af91e7b360225d3e73dd2afdd714a7` · CRC32 `239DD0DF` · SNES checksum `F6C4` · status: production v0.5 + accepted Celes Annex slice

| ID | PC | SNES | Len | Original | New | Consumer / reason |
|---|---|---|---|---|---|---|
| P000_EXPAND_4MIB | 300000–3FFFFF | F0:0000–FF:FFFF | 1048576 | `` | `FF fill` | All F0-FF expansion allocations. — Expand 3 MiB -> 4 MiB HiROM. Header ROM-size byte C0:FFD7 is already 0x0C (4 MiB class) in Rev 1; unchanged. |
| P001_BUILD_METADATA | 300000–30003F | F0:0000–F0:003F | 64 | `FF fill (expansion)` | `46 46 36 58 2D 45 45 00 01 00 05 00 00 02 00 00 63 65 6C …` | tools/verify (offline). No runtime consumer. — Machine-readable build identity for QA tooling. |
| P101_EXP_DLG_TABLE | 334000–33402A | F3:4000–F3:402A | 43 | `FF fill (expansion)` | `24 37 2F 20 2D 32 28 2E 2D 7F 23 28 20 2B 2E 26 34 24 7F …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1000: 'EXPANSION DIALOGUE ERROR:{n}ID OUT OF RANGE.' |
| P101_EXP_DLG_TABLE | 33402B–334061 | F3:402B–F3:4061 | 55 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 57 61 7F 20 47 47 3E 51 7F 4D 3E …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1001: 'TECH v0.3: Annex test map.{n}Enter the Annex?{n}{choice} Yes{n}{choice} No' |
| P101_EXP_DLG_TABLE | 334062–3340D5 | F3:4062–F3:40D5 | 116 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1002: 'VALE (placeholder): TECH v0.3.{n}This text is from bank F3.{n}Annex flag STARTED is now ON.{n}The north door is unsealed.' |
| P101_EXP_DLG_TABLE | 3340D6–33413D | F3:40D6–F3:413D | 104 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1003: 'VALE (placeholder):{n}Annex flag STARTED is still ON.{n}Go north through the door{n}to start the test battle.' |
| P101_EXP_DLG_TABLE | 33413E–3341A6 | F3:413E–F3:41A6 | 105 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1004: 'VALE (placeholder):{n}Annex flag BATTLE DONE is ON.{n}Take the test reward from{n}the chest in the north room.' |
| P101_EXP_DLG_TABLE | 3341A7–33420E | F3:41A7–F3:420E | 104 | `FF fill (expansion)` | `35 20 2B 24 7F 6B 49 45 3A 3C 3E 41 48 45 3D 3E 4B 6C 61 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1005: 'VALE (placeholder):{n}Annex flag COMPLETE is ON.{n}TECH slice finished. Exit{n}south to return to the Falcon.' |
| P101_EXP_DLG_TABLE | 33420F–334238 | F3:420F–F3:4238 | 42 | `FF fill (expansion)` | `33 41 3E 7F 3D 48 48 4B 7F 42 4C 7F 4C 3E 3A 45 3E 3D 65 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1006: 'The door is sealed.{n}(Talk to VALE first.)' |
| P101_EXP_DLG_TABLE | 334239–334271 | F3:4239–F3:4271 | 57 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 57 61 7F 20 47 47 3E 51 7F 3D 3E …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1007: 'TECH v0.3: Annex defenses{n}activate! (placeholder battle)' |
| P101_EXP_DLG_TABLE | 334272–3342A2 | F3:4272–F3:42A2 | 49 | `FF fill (expansion)` | `23 3E 3F 3E 47 4C 3E 4C 7F 3A 4B 3E 7F 3D 48 50 47 65 01 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1008: 'Defenses are down.{n}Annex flag BATTLE DONE is ON.' |
| P101_EXP_DLG_TABLE | 3342A3–3342EE | F3:42A3–F3:42EE | 76 | `FF fill (expansion)` | `33 24 22 27 7F 4F 54 65 57 7F 49 45 3A 3C 3E 41 48 45 3D …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $1009: 'TECH v0.3 placeholder reward:{n}Received 1 Potion.{n}Annex flag COMPLETE is ON.' |
| P101_EXP_DLG_TABLE | 3342EF–33431A | F3:42EF–F3:431A | 44 | `FF fill (expansion)` | `33 41 3E 7F 3C 41 3E 4C 4D 7F 42 4C 7F 3E 46 49 4D 52 65 …` | field text renderer via $C9/$CB set by P100 hook — Expansion dialogue $100A: 'The chest is empty.{n}(Reward already taken.)' |
| P101_EXP_DLG_TABLE | 330000–33002B | F3:0000–F3:002B | 44 | `FF fill (expansion)` | `00 40 F3 00 2B 40 F3 00 62 40 F3 00 D6 40 F3 00 3E 41 F3 …` | P100 hook (LDA.l table,X) — 11 x 4-byte pointers for dialogue IDs $1000-$100A |
| P100_DLG_HOOK | 301000–301032 | F0:1000–F0:1032 | 51 | `FF fill (expansion)` | `C2 20 A5 D0 C9 00 10 B0 0A E2 20 A9 CD 85 CB 5C C3 7F C0 …` | JML from C0:7FBF (GetDlgPtr) — Dialogue-pointer hook: vanilla IDs unchanged, IDs $1000+ from expansion table |
| P100_DLG_HOOK | 007FBF–007FC2 | C0:7FBF–C0:7FC2 | 4 | `A9 CD 85 CB` | `5C 00 10 F0` | GetDlgPtr C0:7FBF; callers C0:A49A ($48), C0:A4E1 ($4B), C0:D493 (debug) — Replace LDA #$CD / STA $CB with JML $F01000 (displaced code re-executed in hook) |
| T400_ANNEX_EVENTS | 310000–31007E | F1:0000–F1:007E | 127 | `FF fill (expansion)` | `4B 01 10 B6 0A 00 27 1B 00 27 DC F8 C0 4C 81 14 00 27 DC …` | event interpreter via 24-bit trigger pointers, NPC vectors, call/jump operands — celes_annex_tech event scripts (127 bytes) from events/celes_annex_tech/events.evt |
| T402_ANNEX_LAYOUT | 350000–350481 | F5:0000–F5:0481 | 1154 | `FF fill (expansion)` | `<1154 bytes, sha1 97530fee0e90617be22c2a6af2f1c6556c55766b>` | LoadMapTiles via MAPX_SUBTILEMAP_PTRS[$15F] — map 0C7 BG1 layout $15F (32x32, literal LZSS 1154 B) |
| M101_MAPX_EVENT_TRIGGERS | 360000–361AC7 | F6:0000–F6:1AC7 | 6856 | `FF fill (expansion)` | `<6856 bytes, sha1 31c6fe7f06eb6373f9dac50707a66a63ec30bfbf>` | 12 retargeted consumers — EVENT_TRIGGERS: 1164 vanilla records (maps $000-$19F) + 2 content records; 513 pointers |
| M102_MAPX_NPC_PROPS | 364000–36912C | F6:4000–F6:912C | 20781 | `FF fill (expansion)` | `<20781 bytes, sha1 4d911af0d02778d45c503514a3752a30f5e28fa4>` | 21 retargeted consumers — NPC_PROPS: 2193 vanilla records (maps $000-$19F) + 2 content records; 513 pointers |
| M103_MAPX_SHORT_ENTRANCES | 36C000–36DE7D | F6:C000–F6:DE7D | 7806 | `FF fill (expansion)` | `<7806 bytes, sha1 e406551057fc40cd13b1f62036a13129e285bf56>` | 19 retargeted consumers — SHORT_ENTRANCES: 1129 vanilla records (maps $000-$1FF) + 1 content records; 513 pointers |
| M104_MAPX_LONG_ENTRANCES | 370000–370829 | F7:0000–F7:0829 | 2090 | `FF fill (expansion)` | `<2090 bytes, sha1 f51157f2bcb62c06ce4a30d372a0565f7038031d>` | 19 retargeted consumers — LONG_ENTRANCES: 152 vanilla records (maps $000-$1FF) + 0 content records; 513 pointers |
| M105_MAPX_TREASURE | 372000–372997 | F7:2000–F7:2997 | 2456 | `FF fill (expansion)` | `<2456 bytes, sha1 da3999f9095378d1e09f048ecd0039465600bed1>` | 12 retargeted consumers — TREASURE: 286 vanilla records (maps $000-$19E) + 0 content records; 513 pointers |
| M106_MAPX_MAP_PROPS | 374000–3781FF | F7:4000–F7:81FF | 16896 | `FF fill (expansion)` | `<16896 bytes, sha1 f7be7fb9b65b217ae353e19e2ba751d0868d5c67>` | LoadMapProp C0:1CAD (LDA.l MapProp,X; X = map*33) — 512 x 33-byte rows: vanilla $000-$19E copied; content rows ['0C7'] |
| M107_MAPX_SUBTILEMAP_PTRS | 378400–378FFF | F7:8400–F7:8FFF | 3072 | `FF fill (expansion)` | `<3072 bytes, sha1 1af658285360332ccbb6d36c11883107bd1245fe>` | LoadMapTiles C0:2883 (BG1/BG2/BG3, 10-bit index * 3) — 1024 layout pointers: vanilla $000-$15E copied, unassigned = entry $000 value; content ['15F'] |
| M108_NPC_EVENT_VECTORS | 379000–379005 | F7:9000–F7:9005 | 6 | `FF fill (expansion)` | `1C 00 F1 69 00 F1` | M300 router (LDA.l vectors,X) — NPC event vectors: #0=F1:001C (0C7:VALE_PLACEHOLDER->EvVale), #1=F1:0069 (0C7:REWARD_CHEST->EvChest) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCAF–00BCB1 | C0:BCAF–C0:BCB1 | 3 | `02 00 C4` | `02 00 F6` | C0:BCAE opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCB5–00BCB7 | C0:BCB5–C0:BCB7 | 3 | `00 00 C4` | `00 00 F6` | C0:BCB4 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCBE–00BCC0 | C0:BCBE–C0:BCC0 | 3 | `00 00 C4` | `00 00 F6` | C0:BCBD opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCD4–00BCD6 | C0:BCD4–C0:BCD6 | 3 | `02 00 C4` | `02 00 F6` | C0:BCD3 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 00BCEE–00BCF0 | C0:BCEE–C0:BCF0 | 3 | `04 00 C4` | `04 00 F6` | C0:BCED opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0004 -> F6:0004 (ptr base + 4) |
| M200_RETARGET_EVENT_TRIGGERS | 2E2177–2E2179 | EE:2177–EE:2179 | 3 | `00 00 C4` | `00 00 F6` | EE:2176 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 2E217D–2E217F | EE:217D–EE:217F | 3 | `02 00 C4` | `02 00 F6` | EE:217C opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 2E218C–2E218E | EE:218C–EE:218E | 3 | `00 00 C4` | `00 00 F6` | EE:218B opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0000 -> F6:0000 (ptr base + 0) |
| M200_RETARGET_EVENT_TRIGGERS | 2E2194–2E2196 | EE:2194–EE:2196 | 3 | `01 00 C4` | `01 00 F6` | EE:2193 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0001 -> F6:0001 (ptr base + 1) |
| M200_RETARGET_EVENT_TRIGGERS | 2E219C–2E219E | EE:219C–EE:219E | 3 | `02 00 C4` | `02 00 F6` | EE:219B opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0002 -> F6:0002 (ptr base + 2) |
| M200_RETARGET_EVENT_TRIGGERS | 2E21A5–2E21A7 | EE:21A5–EE:21A7 | 3 | `03 00 C4` | `03 00 F6` | EE:21A4 opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0003 -> F6:0003 (ptr base + 3) |
| M200_RETARGET_EVENT_TRIGGERS | 2E21AD–2E21AF | EE:21AD–EE:21AF | 3 | `04 00 C4` | `04 00 F6` | EE:21AC opcode BF (long,X) reads EVENT_TRIGGERS — operand C4:0004 -> F6:0004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 0052BD–0052BF | C0:52BD–C0:52BF | 3 | `12 1A C4` | `02 40 F6` | C0:52BC opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052C3–0052C5 | C0:52C3–C0:52C5 | 3 | `10 1A C4` | `00 40 F6` | C0:52C2 opcode BF (long,X) reads NPC_PROPS — operand C4:1A10 -> F6:4000 (ptr base + 0) |
| M200_RETARGET_NPC_PROPS | 0052D5–0052D7 | C0:52D5–C0:52D7 | 3 | `10 1A C4` | `00 40 F6` | C0:52D4 opcode BF (long,X) reads NPC_PROPS — operand C4:1A10 -> F6:4000 (ptr base + 0) |
| M200_RETARGET_NPC_PROPS | 0052DC–0052DE | C0:52DC–C0:52DE | 3 | `11 1A C4` | `01 40 F6` | C0:52DB opcode BF (long,X) reads NPC_PROPS — operand C4:1A11 -> F6:4001 (ptr base + 1) |
| M200_RETARGET_NPC_PROPS | 0052E3–0052E5 | C0:52E3–C0:52E5 | 3 | `12 1A C4` | `02 40 F6` | C0:52E2 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052EC–0052EE | C0:52EC–C0:52EE | 3 | `12 1A C4` | `02 40 F6` | C0:52EB opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 0052F9–0052FB | C0:52F9–C0:52FB | 3 | `12 1A C4` | `02 40 F6` | C0:52F8 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 005306–005308 | C0:5306–C0:5308 | 3 | `12 1A C4` | `02 40 F6` | C0:5305 opcode BF (long,X) reads NPC_PROPS — operand C4:1A12 -> F6:4002 (ptr base + 2) |
| M200_RETARGET_NPC_PROPS | 005322–005324 | C0:5322–C0:5324 | 3 | `14 1A C4` | `04 40 F6` | C0:5321 opcode BF (long,X) reads NPC_PROPS — operand C4:1A14 -> F6:4004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 00532D–00532F | C0:532D–C0:532F | 3 | `14 1A C4` | `04 40 F6` | C0:532C opcode BF (long,X) reads NPC_PROPS — operand C4:1A14 -> F6:4004 (ptr base + 4) |
| M200_RETARGET_NPC_PROPS | 00533B–00533D | C0:533B–C0:533D | 3 | `15 1A C4` | `05 40 F6` | C0:533A opcode BF (long,X) reads NPC_PROPS — operand C4:1A15 -> F6:4005 (ptr base + 5) |
| M200_RETARGET_NPC_PROPS | 00535B–00535D | C0:535B–C0:535D | 3 | `15 1A C4` | `05 40 F6` | C0:535A opcode BF (long,X) reads NPC_PROPS — operand C4:1A15 -> F6:4005 (ptr base + 5) |
| M200_RETARGET_NPC_PROPS | 00536A–00536C | C0:536A–C0:536C | 3 | `16 1A C4` | `06 40 F6` | C0:5369 opcode BF (long,X) reads NPC_PROPS — operand C4:1A16 -> F6:4006 (ptr base + 6) |
| M200_RETARGET_NPC_PROPS | 005374–005376 | C0:5374–C0:5376 | 3 | `17 1A C4` | `07 40 F6` | C0:5373 opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 005380–005382 | C0:5380–C0:5382 | 3 | `17 1A C4` | `07 40 F6` | C0:537F opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 00538B–00538D | C0:538B–C0:538D | 3 | `17 1A C4` | `07 40 F6` | C0:538A opcode BF (long,X) reads NPC_PROPS — operand C4:1A17 -> F6:4007 (ptr base + 7) |
| M200_RETARGET_NPC_PROPS | 005398–00539A | C0:5398–C0:539A | 3 | `18 1A C4` | `08 40 F6` | C0:5397 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053AE–0053B0 | C0:53AE–C0:53B0 | 3 | `18 1A C4` | `08 40 F6` | C0:53AD opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053BD–0053BF | C0:53BD–C0:53BF | 3 | `18 1A C4` | `08 40 F6` | C0:53BC opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053D1–0053D3 | C0:53D1–C0:53D3 | 3 | `18 1A C4` | `08 40 F6` | C0:53D0 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_NPC_PROPS | 0053E4–0053E6 | C0:53E4–C0:53E6 | 3 | `18 1A C4` | `08 40 F6` | C0:53E3 opcode BF (long,X) reads NPC_PROPS — operand C4:1A18 -> F6:4008 (ptr base + 8) |
| M200_RETARGET_SHORT_ENTRANCES | 001A7E–001A80 | C0:1A7E–C0:1A80 | 3 | `02 BB DF` | `02 C0 F6` | C0:1A7D opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001A84–001A86 | C0:1A84–C0:1A86 | 3 | `00 BB DF` | `00 C0 F6` | C0:1A83 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 001A90–001A92 | C0:1A90–C0:1A92 | 3 | `00 BB DF` | `00 C0 F6` | C0:1A8F opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 001AAB–001AAD | C0:1AAB–C0:1AAD | 3 | `02 BB DF` | `02 C0 F6` | C0:1AAA opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AB7–001AB9 | C0:1AB7–C0:1AB9 | 3 | `02 BB DF` | `02 C0 F6` | C0:1AB6 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AC3–001AC5 | C0:1AC3–C0:1AC5 | 3 | `02 BB DF` | `02 C0 F6` | C0:1AC2 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001AD2–001AD4 | C0:1AD2–C0:1AD4 | 3 | `04 BB DF` | `04 C0 F6` | C0:1AD1 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_SHORT_ENTRANCES | 001AE7–001AE9 | C0:1AE7–C0:1AE9 | 3 | `04 BB DF` | `04 C0 F6` | C0:1AE6 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_SHORT_ENTRANCES | 001AF1–001AF3 | C0:1AF1–C0:1AF3 | 3 | `03 BB DF` | `03 C0 F6` | C0:1AF0 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001AFE–001B00 | C0:1AFE–C0:1B00 | 3 | `03 BB DF` | `03 C0 F6` | C0:1AFD opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001B0C–001B0E | C0:1B0C–C0:1B0E | 3 | `03 BB DF` | `03 C0 F6` | C0:1B0B opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 001B2D–001B2F | C0:1B2D–C0:1B2F | 3 | `02 BB DF` | `02 C0 F6` | C0:1B2C opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 001B5F–001B61 | C0:1B5F–C0:1B61 | 3 | `03 BB DF` | `03 C0 F6` | C0:1B5E opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB03 -> F6:C003 (ptr base + 3) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20EA–2E20EC | EE:20EA–EE:20EC | 3 | `00 BB DF` | `00 C0 F6` | EE:20E9 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20F0–2E20F2 | EE:20F0–EE:20F2 | 3 | `02 BB DF` | `02 C0 F6` | EE:20EF opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 2E20FF–2E2101 | EE:20FF–EE:2101 | 3 | `00 BB DF` | `00 C0 F6` | EE:20FE opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB00 -> F6:C000 (ptr base + 0) |
| M200_RETARGET_SHORT_ENTRANCES | 2E2107–2E2109 | EE:2107–EE:2109 | 3 | `01 BB DF` | `01 C0 F6` | EE:2106 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB01 -> F6:C001 (ptr base + 1) |
| M200_RETARGET_SHORT_ENTRANCES | 2E2111–2E2113 | EE:2111–EE:2113 | 3 | `02 BB DF` | `02 C0 F6` | EE:2110 opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB02 -> F6:C002 (ptr base + 2) |
| M200_RETARGET_SHORT_ENTRANCES | 2E213D–2E213F | EE:213D–EE:213F | 3 | `04 BB DF` | `04 C0 F6` | EE:213C opcode BF (long,X) reads SHORT_ENTRANCES — operand DF:BB04 -> F6:C004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0018EB–0018ED | C0:18EB–C0:18ED | 3 | `82 F4 ED` | `02 00 F7` | C0:18EA opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F482 -> F7:0002 (ptr base + 2) |
| M200_RETARGET_LONG_ENTRANCES | 0018F1–0018F3 | C0:18F1–C0:18F3 | 3 | `80 F4 ED` | `00 00 F7` | C0:18F0 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 001904–001906 | C0:1904–C0:1906 | 3 | `82 F4 ED` | `02 00 F7` | C0:1903 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F482 -> F7:0002 (ptr base + 2) |
| M200_RETARGET_LONG_ENTRANCES | 00190C–00190E | C0:190C–C0:190E | 3 | `81 F4 ED` | `01 00 F7` | C0:190B opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001917–001919 | C0:1917–C0:1919 | 3 | `80 F4 ED` | `00 00 F7` | C0:1916 opcode FF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 00191F–001921 | C0:191F–C0:1921 | 3 | `80 F4 ED` | `00 00 F7` | C0:191E opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 001930–001932 | C0:1930–C0:1932 | 3 | `80 F4 ED` | `00 00 F7` | C0:192F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F480 -> F7:0000 (ptr base + 0) |
| M200_RETARGET_LONG_ENTRANCES | 00193B–00193D | C0:193B–C0:193D | 3 | `81 F4 ED` | `01 00 F7` | C0:193A opcode FF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001943–001945 | C0:1943–C0:1945 | 3 | `81 F4 ED` | `01 00 F7` | C0:1942 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F481 -> F7:0001 (ptr base + 1) |
| M200_RETARGET_LONG_ENTRANCES | 001964–001966 | C0:1964–C0:1966 | 3 | `83 F4 ED` | `03 00 F7` | C0:1963 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 001970–001972 | C0:1970–C0:1972 | 3 | `83 F4 ED` | `03 00 F7` | C0:196F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 00197C–00197E | C0:197C–C0:197E | 3 | `83 F4 ED` | `03 00 F7` | C0:197B opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 00198B–00198D | C0:198B–C0:198D | 3 | `85 F4 ED` | `05 00 F7` | C0:198A opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F485 -> F7:0005 (ptr base + 5) |
| M200_RETARGET_LONG_ENTRANCES | 0019A0–0019A2 | C0:19A0–C0:19A2 | 3 | `85 F4 ED` | `05 00 F7` | C0:199F opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F485 -> F7:0005 (ptr base + 5) |
| M200_RETARGET_LONG_ENTRANCES | 0019AA–0019AC | C0:19AA–C0:19AC | 3 | `84 F4 ED` | `04 00 F7` | C0:19A9 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019B7–0019B9 | C0:19B7–C0:19B9 | 3 | `84 F4 ED` | `04 00 F7` | C0:19B6 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019C5–0019C7 | C0:19C5–C0:19C7 | 3 | `84 F4 ED` | `04 00 F7` | C0:19C4 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_LONG_ENTRANCES | 0019E6–0019E8 | C0:19E6–C0:19E8 | 3 | `83 F4 ED` | `03 00 F7` | C0:19E5 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F483 -> F7:0003 (ptr base + 3) |
| M200_RETARGET_LONG_ENTRANCES | 001A15–001A17 | C0:1A15–C0:1A17 | 3 | `84 F4 ED` | `04 00 F7` | C0:1A14 opcode BF (long,X) reads LONG_ENTRANCES — operand ED:F484 -> F7:0004 (ptr base + 4) |
| M200_RETARGET_TREASURE | 0015DE–0015E0 | C0:15DE–C0:15E0 | 3 | `F6 82 ED` | `02 20 F7` | C0:15DD opcode BF (long,X) reads TREASURE — operand ED:82F6 -> F7:2002 (ptr base + 2) |
| M200_RETARGET_TREASURE | 0015E4–0015E6 | C0:15E4–C0:15E6 | 3 | `F4 82 ED` | `00 20 F7` | C0:15E3 opcode BF (long,X) reads TREASURE — operand ED:82F4 -> F7:2000 (ptr base + 0) |
| M200_RETARGET_TREASURE | 0015F2–0015F4 | C0:15F2–C0:15F4 | 3 | `34 86 ED` | `02 24 F7` | C0:15F1 opcode BF (long,X) reads TREASURE — operand ED:8634 -> F7:2402 (data base + 0) |
| M200_RETARGET_TREASURE | 0015F8–0015FA | C0:15F8–C0:15FA | 3 | `35 86 ED` | `03 24 F7` | C0:15F7 opcode BF (long,X) reads TREASURE — operand ED:8635 -> F7:2403 (data base + 1) |
| M200_RETARGET_TREASURE | 0015FF–001601 | C0:15FF–C0:1601 | 3 | `36 86 ED` | `04 24 F7` | C0:15FE opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_TREASURE | 00160A–00160C | C0:160A–C0:160C | 3 | `36 86 ED` | `04 24 F7` | C0:1609 opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_TREASURE | 004BDB–004BDD | C0:4BDB–C0:4BDD | 3 | `F6 82 ED` | `02 20 F7` | C0:4BDA opcode BF (long,X) reads TREASURE — operand ED:82F6 -> F7:2002 (ptr base + 2) |
| M200_RETARGET_TREASURE | 004BE1–004BE3 | C0:4BE1–C0:4BE3 | 3 | `F4 82 ED` | `00 20 F7` | C0:4BE0 opcode BF (long,X) reads TREASURE — operand ED:82F4 -> F7:2000 (ptr base + 0) |
| M200_RETARGET_TREASURE | 004BED–004BEF | C0:4BED–C0:4BEF | 3 | `34 86 ED` | `02 24 F7` | C0:4BEC opcode BF (long,X) reads TREASURE — operand ED:8634 -> F7:2402 (data base + 0) |
| M200_RETARGET_TREASURE | 004BF5–004BF7 | C0:4BF5–C0:4BF7 | 3 | `35 86 ED` | `03 24 F7` | C0:4BF4 opcode BF (long,X) reads TREASURE — operand ED:8635 -> F7:2403 (data base + 1) |
| M200_RETARGET_TREASURE | 004C09–004C0B | C0:4C09–C0:4C0B | 3 | `38 86 ED` | `06 24 F7` | C0:4C08 opcode BF (long,X) reads TREASURE — operand ED:8638 -> F7:2406 (data base + 4) |
| M200_RETARGET_TREASURE | 004C0F–004C11 | C0:4C0F–C0:4C11 | 3 | `36 86 ED` | `04 24 F7` | C0:4C0E opcode BF (long,X) reads TREASURE — operand ED:8636 -> F7:2404 (data base + 2) |
| M200_RETARGET_MAP_PROPS | 001CC0–001CC2 | C0:1CC0–C0:1CC2 | 3 | `00 8F ED` | `00 40 F7` | C0:1CBF opcode BF (long,X) reads MAP_PROPS — operand ED:8F00 -> F7:4000 (data base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 002893–002895 | C0:2893–C0:2895 | 3 | `90 CD D9` | `00 84 F7` | C0:2892 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028A0–0028A2 | C0:28A0–C0:28A2 | 3 | `92 CD D9` | `02 84 F7` | C0:289F opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028E7–0028E9 | C0:28E7–C0:28E9 | 3 | `90 CD D9` | `00 84 F7` | C0:28E6 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 0028F4–0028F6 | C0:28F4–C0:28F6 | 3 | `92 CD D9` | `02 84 F7` | C0:28F3 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M200_RETARGET_SUBTILEMAP_PTRS | 00293D–00293F | C0:293D–C0:293F | 3 | `90 CD D9` | `00 84 F7` | C0:293C opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD90 -> F7:8400 (ptr base + 0) |
| M200_RETARGET_SUBTILEMAP_PTRS | 00294A–00294C | C0:294A–C0:294C | 3 | `92 CD D9` | `02 84 F7` | C0:2949 opcode BF (long,X) reads SUBTILEMAP_PTRS — operand D9:CD92 -> F7:8402 (ptr base + 2) |
| M300_NPC_EVENT_ROUTER | 301100–301146 | F0:1100–F0:1146 | 71 | `FF fill (expansion)` | `29 03 C9 03 D0 3D BF 04 40 F6 30 35 C2 20 B9 89 08 C9 02 …` | JSL from C0:52E6 (InitNPCs) — NPC event router: vanilla NPCs unchanged; non-special NPCs with event field $3xxxx -> vector table |
| M300_NPC_EVENT_ROUTER | 0052E6–0052EA | C0:52E6–C0:52EA | 5 | `29 03 99 8B 08` | `22 00 11 F0 EA` | InitNPCs C0:52E6 (after LDA NPCProp::EventPtr+2,X) — AND #$03 / STA $088B,Y -> JSL F0:1100 / NOP (router re-executes both for vanilla NPCs) |
| N101_MONSTER_PROP | 380000–383FFF | F8:0000–F8:3FFF | 16384 | `FF fill (expansion)` | `<16384 bytes, sha1 e2189a7df88e41678434cf0ee3afdfa24b98d9a2>` | 25 retargeted consumers — MONSTER_PROP relocated (16384 bytes); vanilla entries byte-identical; content: none |
| N102_MONSTER_NAME | 384000–3853FF | F8:4000–F8:53FF | 5120 | `FF fill (expansion)` | `<5120 bytes, sha1 63ace3d6076452374a17b6977d912f653d354ac9>` | 6 retargeted consumers — MONSTER_NAME relocated (5120 bytes); vanilla entries byte-identical; content: none |
| N103_MONSTER_SPECIAL_NAME | 385400–3867FF | F8:5400–F8:67FF | 5120 | `FF fill (expansion)` | `<5120 bytes, sha1 4bfabfe48907716a893c9797a2c4dbc197285b0a>` | 2 retargeted consumers — MONSTER_SPECIAL_NAME relocated (5120 bytes); vanilla entries byte-identical; content: none |
| N104_MONSTER_ITEMS | 386800–386FFF | F8:6800–F8:6FFF | 2048 | `FF fill (expansion)` | `<2048 bytes, sha1 91c840de78fafd5f706b5e85e99ba5dbc4d265c0>` | 2 retargeted consumers — MONSTER_ITEMS relocated (2048 bytes); vanilla entries byte-identical; content: none |
| N105_MONSTER_CONTROL | 387000–3877FF | F8:7000–F8:77FF | 2048 | `FF fill (expansion)` | `<2048 bytes, sha1 53f8640cb48680626d6852f8c9f37cf4e513c5fa>` | 3 retargeted consumers — MONSTER_CONTROL relocated (2048 bytes); vanilla entries byte-identical; content: none |
| N106_MONSTER_SKETCH | 387800–387BFF | F8:7800–F8:7BFF | 1024 | `FF fill (expansion)` | `<1024 bytes, sha1 c6bce88dfd9d3b1f2e5e8896a1732a59f6a581c2>` | 1 retargeted consumers — MONSTER_SKETCH relocated (1024 bytes); vanilla entries byte-identical; content: none |
| N107_MONSTER_SPECIAL_ANIM | 387C00–387DFF | F8:7C00–F8:7DFF | 512 | `FF fill (expansion)` | `03 03 0D 18 07 0E 1B 21 0C 10 0B 0C 0C 00 1C 0E 12 0B 15 …` | 2 retargeted consumers — MONSTER_SPECIAL_ANIM relocated (512 bytes); vanilla entries byte-identical; content: none |
| N108_MONSTER_OVERLAP | 387E00–387FFF | F8:7E00–F8:7FFF | 512 | `FF fill (expansion)` | `00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 …` | 1 retargeted consumers — MONSTER_OVERLAP relocated (512 bytes); vanilla entries byte-identical; content: none |
| N109_MONSTER_GFX_PROP | 388000–388A9A | F8:8000–F8:8A9A | 2715 | `FF fill (expansion)` | `<2715 bytes, sha1 ba2bb9ebfe25e37a30e1e0de01f095e586144e08>` | 15 retargeted consumers — MONSTER_GFX_PROP relocated (2715 bytes); vanilla entries byte-identical; content: none |
| N112_AI_SCRIPT_PTRS | 390000–3903FF | F9:0000–F9:03FF | 1024 | `FF fill (expansion)` | `<1024 bytes, sha1 9bb0dba2928867b36b37f61a485c5aadaecad6d6>` | 1 retargeted consumers — AI_SCRIPT_PTRS relocated (1024 bytes); vanilla entries byte-identical; content: none |
| N113_AI_SCRIPT | 390400–393D51 | F9:0400–F9:3D51 | 14674 | `FF fill (expansion)` | `<14674 bytes, sha1 d6b9bbb4dccd2bd18a9b7d96c8ee5b895043f702>` | 4 retargeted consumers — AI_SCRIPT relocated (14674 bytes); vanilla entries byte-identical; content: none |
| N110_FORMATION_PROP | 389000–389FFF | F8:9000–F8:9FFF | 4096 | `FF fill (expansion)` | `<4096 bytes, sha1 8e1b7022fc90788852585cc42cfb43396b27e291>` | 2 retargeted consumers — FORMATION_PROP relocated (4096 bytes); vanilla entries byte-identical; content: none |
| N111_FORMATION_MONSTERS | 38A000–38DC0F | F8:A000–F8:DC0F | 15376 | `FF fill (expansion)` | `<15376 bytes, sha1 0f85b8c489c32aaed89f011d78ca7da9feb53ad8>` | 7 retargeted consumers — FORMATION_MONSTERS relocated (15376 bytes); vanilla entries byte-identical; content: none |
| N200_RETARGET_MONSTER_PROP | 020626–020628 | C2:0626–C2:0628 | 3 | `1A 00 CF` | `1A 00 F8` | C2:0625 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 26 |
| N200_RETARGET_MONSTER_PROP | 022CA4–022CA6 | C2:2CA4–C2:2CA6 | 3 | `05 00 CF` | `05 00 F8` | C2:2CA3 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 5 |
| N200_RETARGET_MONSTER_PROP | 022CAB–022CAD | C2:2CAB–C2:2CAD | 3 | `0C 00 CF` | `0C 00 F8` | C2:2CAA opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 12 |
| N200_RETARGET_MONSTER_PROP | 022CB2–022CB4 | C2:2CB2–C2:2CB4 | 3 | `0E 00 CF` | `0E 00 F8` | C2:2CB1 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 14 |
| N200_RETARGET_MONSTER_PROP | 022CBE–022CC0 | C2:2CBE–C2:2CC0 | 3 | `0A 00 CF` | `0A 00 F8` | C2:2CBD opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 10 |
| N200_RETARGET_MONSTER_PROP | 022CC8–022CCA | C2:2CC8–C2:2CCA | 3 | `08 00 CF` | `08 00 F8` | C2:2CC7 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 8 |
| N200_RETARGET_MONSTER_PROP | 022CF6–022CF8 | C2:2CF6–C2:2CF8 | 3 | `01 00 CF` | `01 00 F8` | C2:2CF5 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 1 |
| N200_RETARGET_MONSTER_PROP | 022CFD–022CFF | C2:2CFD–C2:2CFF | 3 | `1A 00 CF` | `1A 00 F8` | C2:2CFC opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 26 |
| N200_RETARGET_MONSTER_PROP | 022D04–022D06 | C2:2D04–C2:2D06 | 3 | `03 00 CF` | `03 00 F8` | C2:2D03 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 3 |
| N200_RETARGET_MONSTER_PROP | 022D0E–022D10 | C2:2D0E–C2:2D10 | 3 | `04 00 CF` | `04 00 F8` | C2:2D0D opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 4 |
| N200_RETARGET_MONSTER_PROP | 022D18–022D1A | C2:2D18–C2:2D1A | 3 | `02 00 CF` | `02 00 F8` | C2:2D17 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 2 |
| N200_RETARGET_MONSTER_PROP | 022D1F–022D21 | C2:2D1F–C2:2D21 | 3 | `10 00 CF` | `10 00 F8` | C2:2D1E opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 16 |
| N200_RETARGET_MONSTER_PROP | 022D26–022D28 | C2:2D26–C2:2D28 | 3 | `00 00 CF` | `00 00 F8` | C2:2D25 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 0 |
| N200_RETARGET_MONSTER_PROP | 022D2D–022D2F | C2:2D2D–C2:2D2F | 3 | `07 00 CF` | `07 00 F8` | C2:2D2C opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 7 |
| N200_RETARGET_MONSTER_PROP | 022D37–022D39 | C2:2D37–C2:2D39 | 3 | `1E 00 CF` | `1E 00 F8` | C2:2D36 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 30 |
| N200_RETARGET_MONSTER_PROP | 022D43–022D45 | C2:2D43–C2:2D45 | 3 | `13 00 CF` | `13 00 F8` | C2:2D42 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 19 |
| N200_RETARGET_MONSTER_PROP | 022DC3–022DC5 | C2:2DC3–C2:2DC5 | 3 | `1F 00 CF` | `1F 00 F8` | C2:2DC2 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 31 |
| N200_RETARGET_MONSTER_PROP | 022DCA–022DCC | C2:2DCA–C2:2DCC | 3 | `19 00 CF` | `19 00 F8` | C2:2DC9 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 25 |
| N200_RETARGET_MONSTER_PROP | 022DD4–022DD6 | C2:2DD4–C2:2DD6 | 3 | `16 00 CF` | `16 00 F8` | C2:2DD3 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 22 |
| N200_RETARGET_MONSTER_PROP | 022DEA–022DEC | C2:2DEA–C2:2DEC | 3 | `1B 00 CF` | `1B 00 F8` | C2:2DE9 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 27 |
| N200_RETARGET_MONSTER_PROP | 022DF1–022DF3 | C2:2DF1–C2:2DF3 | 3 | `1D 00 CF` | `1D 00 F8` | C2:2DF0 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 29 |
| N200_RETARGET_MONSTER_PROP | 022E11–022E13 | C2:2E11–C2:2E13 | 3 | `1C 00 CF` | `1C 00 F8` | C2:2E10 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 28 |
| N200_RETARGET_MONSTER_PROP | 022E1B–022E1D | C2:2E1B–C2:2E1D | 3 | `14 00 CF` | `14 00 F8` | C2:2E1A opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 20 |
| N200_RETARGET_MONSTER_PROP | 022E28–022E2A | C2:2E28–C2:2E2A | 3 | `17 00 CF` | `17 00 F8` | C2:2E27 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 23 |
| N200_RETARGET_MONSTER_PROP | 022E32–022E34 | C2:2E32–C2:2E34 | 3 | `11 00 CF` | `11 00 F8` | C2:2E31 opcode BF (long) reads MONSTER_PROP — long operand -> F8:0000 + 17 |
| N200_RETARGET_MONSTER_NAME | 016641–016643 | C1:6641–C1:6643 | 3 | `50 C0 CF` | `00 40 F8` | C1:6640 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 0169C7–0169C9 | C1:69C7–C1:69C9 | 3 | `50 C0 CF` | `00 40 F8` | C1:69C6 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 022C57–022C59 | C2:2C57–C2:2C59 | 3 | `50 C0 CF` | `00 40 F8` | C2:2C56 opcode BF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 022C79–022C7B | C2:2C79–C2:2C7B | 3 | `50 C0 CF` | `00 40 F8` | C2:2C78 opcode DF (long) reads MONSTER_NAME — long operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 03540F–035410 | C3:540F–C3:5410 | 2 | `50 C0` | `00 40` | C3:540E opcode A0 (imm_near) reads MONSTER_NAME — imm_near operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_NAME | 035414–035414 | C3:5414–C3:5414 | 1 | `CF` | `F8` | C3:5413 opcode A9 (imm_bank) reads MONSTER_NAME — imm_bank operand -> F8:4000 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_NAME | 019739–019739 | C1:9739–C1:9739 | 1 | `CF` | `F8` | C1:9738 opcode A9 (imm_bank) reads MONSTER_SPECIAL_NAME — imm_bank operand -> F8:5400 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_NAME | 01974D–01974E | C1:974D–C1:974E | 2 | `D0 D0` | `00 54` | C1:974C opcode 69 (imm_near) reads MONSTER_SPECIAL_NAME — imm_near operand -> F8:5400 + 0 |
| N200_RETARGET_MONSTER_ITEMS | 022C42–022C44 | C2:2C42–C2:2C44 | 3 | `00 30 CF` | `00 68 F8` | C2:2C41 opcode BF (long) reads MONSTER_ITEMS — long operand -> F8:6800 + 0 |
| N200_RETARGET_MONSTER_ITEMS | 025F2E–025F30 | C2:5F2E–C2:5F30 | 3 | `02 30 CF` | `02 68 F8` | C2:5F2D opcode BF (long) reads MONSTER_ITEMS — long operand -> F8:6800 + 2 |
| N200_RETARGET_MONSTER_CONTROL | 02063E–020640 | C2:063E–C2:0640 | 3 | `00 3D CF` | `00 70 F8` | C2:063D opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 0 |
| N200_RETARGET_MONSTER_CONTROL | 020644–020646 | C2:0644–C2:0646 | 3 | `02 3D CF` | `02 70 F8` | C2:0643 opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 2 |
| N200_RETARGET_MONSTER_CONTROL | 023759–02375B | C2:3759–C2:375B | 3 | `00 3D CF` | `00 70 F8` | C2:3758 opcode BF (long) reads MONSTER_CONTROL — long operand -> F8:7000 + 0 |
| N200_RETARGET_MONSTER_SKETCH | 023B5B–023B5D | C2:3B5B–C2:3B5D | 3 | `00 43 CF` | `00 78 F8` | C2:3B5A opcode BF (long) reads MONSTER_SKETCH — long operand -> F8:7800 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_ANIM | 020617–020619 | C2:0617–C2:0619 | 3 | `C0 37 CF` | `00 7C F8` | C2:0616 opcode BF (long) reads MONSTER_SPECIAL_ANIM — long operand -> F8:7C00 + 0 |
| N200_RETARGET_MONSTER_SPECIAL_ANIM | 022D50–022D52 | C2:2D50–C2:2D52 | 3 | `C0 37 CF` | `00 7C F8` | C2:2D4F opcode BF (long) reads MONSTER_SPECIAL_ANIM — long operand -> F8:7C00 + 0 |
| N200_RETARGET_MONSTER_OVERLAP | 012145–012147 | C1:2145–C1:2147 | 3 | `00 36 CF` | `00 7E F8` | C1:2144 opcode BF (long) reads MONSTER_OVERLAP — long operand -> F8:7E00 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 012063–012065 | C1:2063–C1:2065 | 3 | `02 70 D2` | `02 80 F8` | C1:2062 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 012081–012083 | C1:2081–C1:2083 | 3 | `00 70 D2` | `00 80 F8` | C1:2080 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 01208E–012090 | C1:208E–C1:2090 | 3 | `01 70 D2` | `01 80 F8` | C1:208D opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 012097–012099 | C1:2097–C1:2099 | 3 | `02 70 D2` | `02 80 F8` | C1:2096 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 0120AC–0120AE | C1:20AC–C1:20AE | 3 | `04 70 D2` | `04 80 F8` | C1:20AB opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_MONSTER_GFX_PROP | 0124FD–0124FF | C1:24FD–C1:24FF | 3 | `02 70 D2` | `02 80 F8` | C1:24FC opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 01250C–01250E | C1:250C–C1:250E | 3 | `00 70 D2` | `00 80 F8` | C1:250B opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 012519–01251B | C1:2519–C1:251B | 3 | `01 70 D2` | `01 80 F8` | C1:2518 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 012522–012524 | C1:2522–C1:2524 | 3 | `02 70 D2` | `02 80 F8` | C1:2521 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 012537–012539 | C1:2537–C1:2539 | 3 | `04 70 D2` | `04 80 F8` | C1:2536 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF60–03AF62 | C3:AF60–C3:AF62 | 3 | `00 70 D2` | `00 80 F8` | C3:AF5F opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 0 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF66–03AF68 | C3:AF66–C3:AF68 | 3 | `01 70 D2` | `01 80 F8` | C3:AF65 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 1 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF6C–03AF6E | C3:AF6C–C3:AF6E | 3 | `02 70 D2` | `02 80 F8` | C3:AF6B opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 2 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF72–03AF74 | C3:AF72–C3:AF74 | 3 | `03 70 D2` | `03 80 F8` | C3:AF71 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 3 |
| N200_RETARGET_MONSTER_GFX_PROP | 03AF78–03AF7A | C3:AF78–C3:AF7A | 3 | `04 70 D2` | `04 80 F8` | C3:AF77 opcode BF (long) reads MONSTER_GFX_PROP — long operand -> F8:8000 + 4 |
| N200_RETARGET_AI_SCRIPT_PTRS | 022D79–022D7B | C2:2D79–C2:2D7B | 3 | `00 84 CF` | `00 00 F9` | C2:2D78 opcode BF (long) reads AI_SCRIPT_PTRS — long operand -> F9:0000 + 0 |
| N200_RETARGET_AI_SCRIPT | 021A45–021A47 | C2:1A45–C2:1A47 | 3 | `00 87 CF` | `00 04 F9` | C2:1A44 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_AI_SCRIPT | 021A65–021A67 | C2:1A65–C2:1A67 | 3 | `02 87 CF` | `02 04 F9` | C2:1A64 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 2 |
| N200_RETARGET_AI_SCRIPT | 021A6C–021A6E | C2:1A6C–C2:1A6E | 3 | `00 87 CF` | `00 04 F9` | C2:1A6B opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_AI_SCRIPT | 022D89–022D8B | C2:2D89–C2:2D8B | 3 | `00 87 CF` | `00 04 F9` | C2:2D88 opcode BF (long) reads AI_SCRIPT — long operand -> F9:0400 + 0 |
| N200_RETARGET_FORMATION_PROP | 023137–023139 | C2:3137–C2:3139 | 3 | `02 59 CF` | `02 90 F8` | C2:3136 opcode BF (long) reads FORMATION_PROP — long operand -> F8:9000 + 2 |
| N200_RETARGET_FORMATION_PROP | 02313E–023140 | C2:313E–C2:3140 | 3 | `00 59 CF` | `00 90 F8` | C2:313D opcode BF (long) reads FORMATION_PROP — long operand -> F8:9000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010E9A–010E9C | C1:0E9A–C1:0E9C | 3 | `0E 62 CF` | `0E A0 F8` | C1:0E99 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 14 |
| N200_RETARGET_FORMATION_MONSTERS | 010EA2–010EA4 | C1:0EA2–C1:0EA4 | 3 | `00 62 CF` | `00 A0 F8` | C1:0EA1 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010EB5–010EB7 | C1:0EB5–C1:0EB7 | 3 | `00 62 CF` | `00 A0 F8` | C1:0EB4 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N200_RETARGET_FORMATION_MONSTERS | 010EC0–010EC2 | C1:0EC0–C1:0EC2 | 3 | `01 62 CF` | `01 A0 F8` | C1:0EBF opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 1 |
| N200_RETARGET_FORMATION_MONSTERS | 010ED2–010ED4 | C1:0ED2–C1:0ED4 | 3 | `08 62 CF` | `08 A0 F8` | C1:0ED1 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 8 |
| N200_RETARGET_FORMATION_MONSTERS | 010EE0–010EE2 | C1:0EE0–C1:0EE2 | 3 | `08 62 CF` | `08 A0 F8` | C1:0EDF opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 8 |
| N200_RETARGET_FORMATION_MONSTERS | 023156–023158 | C2:3156–C2:3158 | 3 | `00 62 CF` | `00 A0 F8` | C2:3155 opcode BF (long) reads FORMATION_MONSTERS — long operand -> F8:A000 + 0 |
| N300_GFX_SLOT_ROUTERS | 301200–301230 | F0:1200–F0:1230 | 49 | `FF fill (expansion)` | `BD 01 20 C9 80 01 90 03 69 1F 00 48 0A 0A 18 63 01 FA 6B …` | JSL from C1:2058 (battle monster loader), C2:F5F1 (Sketch), C2:2F75 (colosseum detection) — graphics-property slot remap (monsters $180-$1FE -> slots $1A0-$21E) + colosseum range check |
| N301_GFX_SLOT_HOOK_BATTLE | 012058–012060 | C1:2058–C1:2060 | 9 | `BD 01 20 0A 0A 18 7D 01 20` | `22 00 12 F0 EA EA EA EA EA` | LoadMonsterGfxProp (C1:204E) monster id*5 computation — LDA $2001,X/ASL/ASL/CLC/ADC $2001,X -> JSL MonsterGfxSlot5 + 5x NOP |
| N302_GFX_SLOT_HOOK_SKETCH | 02F5F1–02F5F4 | C2:F5F1–C2:F5F4 | 4 | `BD 01 20 AA` | `22 13 12 F0` | battle animation init $0B (Sketch): monster id -> LoadSketchMonsterGfx — LDA $2001,X/TAX -> JSL MonsterGfxSlotSketch |
| N303_FORMATION_COLOSSEUM_RANGE | 022F75–022F7A | C2:2F75–C2:2F7A | 6 | `AE D4 3E E0 3E 02` | `22 20 12 F0 EA EA` | InitParty C2:2F75 colosseum detection (battle id >= $23E) — LDX wBattleID/CPX #$023E -> JSL ColosseumRangeCheck + 2x NOP; colosseum iff $23E <= id < $240 so new formations $240-$3FF load normally |
| P999_CHECKSUM | 00FFDC–00FFDF | C0:FFDC–C0:FFDF | 4 | `9F 75 60 8A` | `3B 09 C4 F6` | SNES header (emulator/flash-cart validation) — Recalculated checksum F6C4 / complement 093B |
