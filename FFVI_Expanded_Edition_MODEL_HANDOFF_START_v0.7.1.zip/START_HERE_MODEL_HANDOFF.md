# FFVI Expanded Edition — Model Handoff
## Current checkpoint: start TECH v0.7.1 Signature Equipment Bank Proof

Use this handoff to continue the project in another model/session without redoing accepted work.

### Clean ROM baseline — HARD LOCK
- Final Fantasy III (USA) (Rev 1) / FFVI US v1.1
- Unheadered size: 0x300000
- SHA-1: 057ADA1C641E3E0B3CA34E6E4F4EB1B05A87143A
- CRC32: C0FA0464
- FastROM HiROM
- Internal revision: 0x01

Always build from the clean Rev 1 ROM. Never edit the clean master ROM in place.

### Latest accepted state
- TECH v0.6.1 = latest runtime-accepted ROM foundation.
- TECH v0.6.2 = tooling-only; no ROM-byte changes.
- TECH v0.7 = audit/decision only; item architecture not implemented yet.

### Approved next task
TECH v0.7.1 — Signature Equipment Bank Proof.

### Files the new model should receive
1. This handoff ZIP.
2. `FF6X_TECH_v0.6.2_FORMATION_SAFETY_v0.7_ITEM_AUDIT.zip`.
3. Clean FFIII USA Rev 1 ROM.
4. Latest builder/source workspace if available.
5. Creative Lock/design pack if production content is later touched.

Read all files first. Do not redo accepted phases.
