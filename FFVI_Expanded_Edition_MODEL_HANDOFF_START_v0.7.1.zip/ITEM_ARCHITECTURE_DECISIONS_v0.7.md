# TECH v0.7 Item Architecture Decision — APPROVED

Rev 1 has no free normal item IDs: `$00-$FE` are real items, `$FF` is Empty.

## Approved choice: Option C — Signature Equipment Bank

Namespace:
- `$100-$126` = 39 locked production equipment concepts
- `$127-$13C` = reserve
- `$13D-$13F` = QA-only IDs

### D1
Use Option C. All 39 concepts remain TRUE EQUIPMENT. Do not replace vanilla item IDs.

### D2
8 new consumables are DEFERRED. Do not cut them, reassign vanilla consumables, or implement full Option B yet.

### D3
Rare/key-item extension approved conceptually. Future target: at least 32 entries. Not part of the first proof unless required.

### D4
Smith-sourced signature gear is EVENT-DRIVEN, not normal shop inventory.

### D5
Relics with optional custom ASM effects use BAL-18 stat fallback first. Special relic ASM is a later module.

### D6
No reforge consumption. Tempered Edge, Raider Knife, Doma Edge are independent new equipment.

## Strong implementation preference
Prefer:
- 32-byte inventory item-ID high-bit bitmap
- 12-byte equipped-item high-bit bitmap
- explicit extension signature/version

over stealing quantity bit 7.

Legacy saves must never infer extended-item high bits from garbage bytes.
