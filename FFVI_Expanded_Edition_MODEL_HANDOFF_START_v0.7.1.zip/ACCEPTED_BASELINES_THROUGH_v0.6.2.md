# Accepted Baselines through TECH v0.6.2

## Creative locks
Do not silently change locked story arcs, voices, canon, map concepts, monster/boss concepts, 39 equipment concepts, reconstruction philosophy, or ending philosophy.

Important canon:
- Kefka remains final antagonist.
- Magic/Espers disappear in ending.
- Leo, Rachel, Darill remain dead.
- Shadow remains dead if not saved.
- Shadow/Relm connection stays implied, not bluntly confessed.
- Vael is not the secret mastermind behind Kefka.
- No multiverse, time travel, fourth god, resurrection retcons, or new permanent playable character.

## TECH v0.1 — ACCEPTED
4 MiB expansion + F0 reads work; save/reset/load OK.

## TECH v0.2 — ACCEPTED
Expanded dialogue + event hook/bridge + persistent bit work.
`$0FF` permanently reserved for TECH_TEST.

## TECH v0.3 — ACCEPTED
New map/NPC/dialogue/event/battle/reward/save-load pipeline works.

Known QA-only issue:
saving/loading during opening Narshe Magitek field sequence restores walking field sprite while battle Magitek state remains correct. Do not patch production save engine for this.

## TECH v0.4 — ACCEPTED
Expanded map foundation works: relocated tables, new map IDs, scalable NPC event-vector routing, triggers, short/long entrances, persistent map state.

## TECH v0.5 — ACCEPTED
Monster IDs above `$17F` work. QA monsters `$180/$181` coexist. Names/stats/AI/targeting/victory/return/save-load and vanilla regression pass. New monsters remain excluded from Rage/Veldt for now.

## TECH v0.6.1 — ACCEPTED
Custom enemy graphics/palette storage and new-formation Magic Points work at runtime.
Earlier Dark Wind corruption was caused by Magitek-party VRAM overlap in the QA formation, not graphics routing.

## TECH v0.6.2 — TOOLING ONLY
No ROM-byte change.
Builder now validates enemy screen margins, generates previews, and checks Magitek VRAM conflicts.

Fully safe VRAM maps with Magitek:
2, 8, 9, 10, 11

Known always-bad examples:
- map 1 slot 5
- map 7 slot 1
- map 12 slot 5

Remaining safety risk:
back/pincer/side attacks and special party states beyond Magitek are not fully mapped.
