# Engineering Rules

1. Build only from clean FFIII USA Rev 1.
2. Abort on baseline hash mismatch.
3. Do not edit master ROM in place.
4. Assert expected original bytes before every write.
5. Record PC and SNES addresses.
6. No blind opcode-pattern patching.
7. Every patch needs an identified consumer/reason.
8. No US v1.0 raw offsets without Rev 1 verification.
9. Keep one authoritative expansion allocation manifest.
10. Reject overlaps.
11. Recompute SNES checksum.
12. Output SHA-1 and CRC32.
13. Produce diff/patch manifest.
14. Keep STATIC / EMULATOR / USER RUNTIME status separate.
15. Never claim user-runtime success without user testing.
16. Accepted runtime builds become named baselines.
17. Prefer minimal reversible patches.
18. Never overwrite vanilla data just because it looks unused.
19. QA placeholders are allowed; production content must follow Creative Lock.
20. Builder/source files are source of truth, not manual editor changes.
