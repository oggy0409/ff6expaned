# NEXT TASK — TECH v0.7.1 Signature Equipment Bank Proof

TECH v0.7 was audit/decision only. No item architecture has been accepted yet.

Implement TECH v0.7.1 as a SMALL ARCHITECTURE PROOF.
Do not populate all 39 production items.

## 1. Saved WRAM / SRAM audit
Fully audit candidate persistent WRAM:
- `$1E1D-$1E3F`
- `$1CF8-$1D27`
and any other candidate if needed.

Cross-reference C0/C1/C2/C3 ASM, field events, menus, battle, initialization, save/load, checksum, and Rev 1 uses.

Preferred architecture if proven safe:
- 32-byte inventory high-bit bitmap
- 12-byte equipped-item high-bit bitmap
- extension signature/version bytes

Prefer a dedicated bitmap over quantity bit 7.

## 2. Legacy save compatibility
Create explicit FF6X item-extension signature/version.

On load:
- valid signature -> load extended metadata
- legacy/no signature -> clear extended-item high-bit metadata, initialize version, preserve vanilla fields

On New Game:
- initialize extended metadata to zero

Avoid changing save-slot size if possible.
Test old saves and synthetic nonzero garbage in candidate bytes.

## 3. QA item IDs
Create only:
- `$13D` = QA weapon
- `$13E` = QA body armor
- `$13F` = QA relic

Use obvious distinct stats.
Do not use production IDs.

## 4. Required extended-ID paths
Implement only what Option C requires:
- ItemProp/name/description lookup
- inventory ID storage/read
- quantities
- equip slots
- equip menu
- relic menu
- item/status/equipment display
- Optimize/Optimum
- Remove/Empty
- Arrange sorting
- battle equipment loading
- weapon animation/data
- hand swap if applicable
- equip masks
- event Give/Take
- save/load
- spear Jump x2 support for future `$1xx` spears

Explicitly exclude `$1xx` signature equipment from:
- normal shops
- Sell
- Steal
- Drop
- Metamorph
- Colosseum wager
- Throw
- other vanilla 1-byte-item sources

Excluded paths must never truncate `$1xx -> $xx`.

## 5. Event reward API
Use accepted expanded-event infrastructure.

Create safe helpers such as:
- `GIVE_EXT_ITEM id`
- `TAKE_EXT_ITEM id`
- `HAS_EXT_ITEM id`

or equivalent.

Do not globally widen vanilla event commands `$80/$81` unless necessary.

## 6. QA proof
QA harness must grant `$13D/$13E/$13F`.

User QA must prove:
A. receive all three
B. correct names/icons/descriptions
C. correct UI placement
D. equip/unequip
E. stats change correctly
F. weapon animation/damage correct
G. relic stat/fallback effect correct
H. Arrange preserves them
I. Optimize handles them
J. save -> reset/power cycle -> load preserves them
K. remove one via extended event API
L. legacy save without signature creates ZERO phantom extended items
M. shops/Sell/Colosseum/Throw cannot expose/truncate them
N. vanilla inventory/equipment unchanged

Also prove multiple extended equipment pieces can be equipped simultaneously.

## 7. Regression
At minimum:
- vanilla inventory with many items
- Arrange
- shops buy/sell
- equip/optimize/remove
- relic menu
- battle weapon animation
- battle Item
- Throw with vanilla items
- Colosseum item list
- vanilla event Give/Take
- save/reset/load
- old-save load
- Celes Annex
- expanded maps
- expanded monsters/custom graphics/MP

All vanilla item IDs `$00-$FE` must still resolve exactly as before.

## 8. Deliverables
Return:
- `README_TECH_v0.7.1.md`
- `USER_QA_TECH_v0.7.1_VI.md`
- `SAVED_RAM_AUDIT_v0.7.1.md`
- `ITEM_CONSUMER_AUDIT_v0.7.1.md`
- `SAVE_COMPATIBILITY_v0.7.1.md`
- updated `allocations.json`
- source definitions for `$13D-$13F`
- deterministic builder
- QA ROM
- production ROM without QA content
- BPS
- exact PC/SNES patch table
- diff manifest
- regression report
- known risks
- hashes

State separately:
- STATIC PASS / FAIL
- EMULATOR PASS / FAIL
- USER RUNTIME QA PENDING

## 9. Do not do yet
Do NOT:
- populate final 39 equipment
- implement the 8 consumables
- implement special relic ASM
- implement key-item expansion unless required for proof
- start final Celes content
- redesign accepted map/monster/graphics foundations

Stop after packaging TECH v0.7.1 for review and user QA.
