# Vanilla FFVI art references (ART ASSET GATE v1.0)

Source: clean *Final Fantasy III (USA) (Rev 1)* ROM. Each crop is a static BG1+BG2 render of the rectangle (metatile units of the source map's BG1); NPCs, BG3 and event-time tile changes are not drawn. These are **candidates only**: nothing is chosen for implementation. Per-candidate detail (every metatile id, its four 8x8 BG words = tile number, palette row, priority, flips, and collision) is in the matching `.json`.

`new 8x8` = unique non-blank 8x8 graphics of the crop that are **not** already in $1A2's VRAM (compared pixel-wise, flips included). 0 means the look can be rebuilt from graphics $1A2 already loads (new metatile definitions only).

| id | category | source map | rect x,y,w,h | tileset BG1 | gfx sets | palette | unique 8x8 | new 8x8 | crop |
|---|---|---|---|---|---|---|---|---|---|
| T1 | temporary memorial | $12A | 68,4,11,6 | $49 DARILLS_TOMB_BG1 | $19 $2E $51 $11 | $28 DARILLS_TOMB_1 | 68 | 66 | `T1_temporary_memorial_MAP12A_68_4_11x6.png` |
| T2 | temporary memorial | $196 | 50,2,10,6 | $1F CASTLE_BASEMENT_BG1 | $0F $10 $11 $12 | $06 CASTLE_INT | 50 | 49 | `T2_temporary_memorial_MAP196_50_2_10x6.png` |
| T3 | temporary memorial | $07B | 46,1,10,6 | $0A CASTLE_INT_BG1 | $0F $10 $11 $12 | $06 CASTLE_INT | 80 | 79 | `T3_temporary_memorial_MAP07B_46_1_10x6.png` |
| T4 | temporary memorial | $131 | 24,6,6,4 | $15 DESTROYED_TOWN_BG1 | $0A $0B $21 $08 | $29 TOWN_EXT_2 | 51 | 50 | `T4_temporary_memorial_MAP131_24_6_6x4.png` |
| T5 | temporary memorial | $112 | 7,3,8,6 | $22 MAGITEK_LAB_1_BG1 | $36 $37 $38 $3A | $18 MAGITEK_FACTORY | 59 | 0 | `T5_temporary_memorial_MAP112_7_3_8x6.png` |
| T6 | temporary memorial | $0FD | 20,7,6,5 | $1D VECTOR_BG1 | $2D $0B $39 $08 | $11 VECTOR | 22 | 19 | `T6_temporary_memorial_MAP0FD_20_7_6x5.png` |
| P1 | permanent memorial | $12A | 9,34,9,6 | $49 DARILLS_TOMB_BG1 | $19 $2E $51 $11 | $28 DARILLS_TOMB_1 | 36 | 35 | `P1_permanent_memorial_MAP12A_9_34_9x6.png` |
| P2 | permanent memorial | $12A | 74,32,9,9 | $49 DARILLS_TOMB_BG1 | $19 $2E $51 $11 | $28 DARILLS_TOMB_1 | 53 | 52 | `P2_permanent_memorial_MAP12A_74_32_9x9.png` |
| P3 | permanent memorial | $11C | 11,0,5,3 | $15 DESTROYED_TOWN_BG1 | $0A $0B $21 $08 | $03 TOWN_EXT_1 | 34 | 34 | `P3_permanent_memorial_MAP11C_11_0_5x3.png` |
| P4 | permanent memorial | $11C | 5,6,5,4 | $15 DESTROYED_TOWN_BG1 | $0A $0B $21 $08 | $03 TOWN_EXT_1 | 25 | 24 | `P4_permanent_memorial_MAP11C_5_6_5x4.png` |
| P5 | permanent memorial | $09E | 23,26,6,5 | $27 VILLAGE_EXT_2_BG1 | $04 $05 $34 $07 | $16 VILLAGE_EXT_3 | 23 | 22 | `P5_permanent_memorial_MAP09E_23_26_6x5.png` |
| P6 | permanent memorial | $196 | 27,39,8,5 | $1F CASTLE_BASEMENT_BG1 | $0F $10 $11 $12 | $06 CASTLE_INT | 60 | 60 | `P6_permanent_memorial_MAP196_27_39_8x5.png` |
| A1 | archive preserve | $039 | 97,8,13,9 | $0A CASTLE_INT_BG1 | $0F $10 $11 $12 | $06 CASTLE_INT | 59 | 58 | `A1_archive_preserve_MAP039_97_8_13x9.png` |
| A2 | archive preserve | $196 | 27,40,4,5 | $1F CASTLE_BASEMENT_BG1 | $0F $10 $11 $12 | $06 CASTLE_INT | 46 | 46 | `A2_archive_preserve_MAP196_27_40_4x5.png` |
| A3 | archive preserve | $0A0 | 57,8,14,6 | $10 TOWN_INT_BG1 | $19 $11 $1B $1A | $24 TOWN_INT_2 | 80 | 79 | `A3_archive_preserve_MAP0A0_57_8_14x6.png` |
| A4 | archive preserve | $018 | 74,4,9,10 | $10 TOWN_INT_BG1 | $19 $11 $1B $1A | $25 NARSHE_INT | 45 | 44 | `A4_archive_preserve_MAP018_74_4_9x10.png` |
| A5 | archive preserve | $106 | 1,22,5,7 | $2F MAGITEK_FACTORY_BG1 | $36 $37 $38 $39 | $18 MAGITEK_FACTORY | 30 | 0 | `A5_archive_preserve_MAP106_1_22_5x7.png` |
| A6 | archive preserve | $10B | 2,1,12,6 | $22 MAGITEK_LAB_1_BG1 | $36 $37 $38 $3A | $18 MAGITEK_FACTORY | 81 | 0 | `A6_archive_preserve_MAP10B_2_1_12x6.png` |
| B1 | archive burn | $11C | 7,7,6,6 | $15 DESTROYED_TOWN_BG1 | $0A $0B $21 $08 | $03 TOWN_EXT_1 | 42 | 41 | `B1_archive_burn_MAP11C_7_7_6x6.png` |
| B2 | archive burn | $09E | 10,5,7,7 | $27 VILLAGE_EXT_2_BG1 | $04 $05 $34 $07 | $16 VILLAGE_EXT_3 | 90 | 89 | `B2_archive_burn_MAP09E_10_5_7x7.png` |
| B3 | archive burn | $15F | 0,1,9,6 | $46 BURNING_BUILDING | $25 $05 $06 $07 | $23 BURNING_BUILDING | 78 | 77 | `B3_archive_burn_MAP15F_0_1_9x6.png` |
| B4 | archive burn | $12A | 102,4,8,11 | $49 DARILLS_TOMB_BG1 | $19 $2E $51 $11 | $28 DARILLS_TOMB_1 | 45 | 44 | `B4_archive_burn_MAP12A_102_4_8x11.png` |
| B5 | archive burn | $143 | 8,8,7,6 | $15 DESTROYED_TOWN_BG1 | $0A $0B $21 $08 | $03 TOWN_EXT_1 | 35 | 34 | `B5_archive_burn_MAP143_8_8_7x6.png` |
| B6 | archive burn | $100 | 4,4,10,7 | $2B KEFKAS_TOWER_BG1 | $23 $24 $42 $4F | $22 KEFKAS_TOWER_1 | 151 | 151 | `B6_archive_burn_MAP100_4_4_10x7.png` |

Labels:

* **T1** - Darill's Tomb - small red-framed plates with a carved face on stone pedestals (tomb markers / switches), wall alcoves with blue flames
* **T2** - Ancient Castle - crossed-sword wall plaques (trophy / commemorative plates)
* **T3** - Doma Castle interior - wall emblems / crossed swords
* **T4** - Tzen - hanging wooden signboards (name-tag style plates)
* **T5** - Magitek Research Facility - esper room wall consoles / panels (same gfx sets as $1A2)
* **T6** - Vector - hanging Imperial banner (cloth banner / name-banner option)
* **P1** - Darill's Tomb - single grave on a dais with headstone
* **P2** - Darill's Tomb - rows of headstones on red grave slabs
* **P3** - Maranda (WoR) - stone obelisk / memorial pillar
* **P4** - Maranda (WoR) - stone obelisk beside a ruined house
* **P5** - Mobliz (WoR) - outdoor headstones
* **P6** - Ancient Castle - gold knight statues, wall plaques, bookshelf
* **A1** - Figaro Castle - library bookshelves
* **A2** - Ancient Castle - single tall bookshelf
* **A3** - Thamasa house interior - wall cabinets and bookshelf
* **A4** - Narshe house interior - shelves / drawers
* **A5** - Magitek Factory - stacked crates (same gfx sets as $1A2)
* **A6** - Magitek Research Facility - plain wall panels and pipe racks (context: same tileset as $1A2)
* **B1** - Maranda (WoR) - house with collapsed roof hole and soot
* **B2** - Mobliz (WoR) - burned / soot-damaged house
* **B3** - Thamasa burning house - flame walls
* **B4** - Darill's Tomb - collapsed masonry / rubble
* **B5** - Albrook (WoR) - damaged roof / soot holes
* **B6** - Kefka's Tower - rubble heaps with wrecked Imperial machinery

`maps/`: full static render of every source map (1 px = 1 px, grid = metatiles, numbers = BG1 coordinates).
`VANILLA_REFERENCE_CONTACT.png`: all crops grouped by category.
